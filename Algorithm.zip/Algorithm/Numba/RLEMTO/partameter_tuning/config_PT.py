import os


class Config1:
    # 需要调的参数
    main_speed_task_size = 50
    low_speed_task_size = 15
    high_speed_task_size = 15
    middle_speed_task_size = 15
    radius = 0.05
    q_alpha = 0.10
    q_gamma = 0.60


    crossover_prob = 0.8
    mutation_prob = 0.2
    g_time = None
    # Q-learning 参数
    q_epsilon_start = 1.0
    q_epsilon_min = 0.10
    @classmethod
    def update_from_problem(cls, problem, file_path):
        scale = os.path.basename(os.path.dirname(file_path))
        cls.g_time = 30 * problem.num_factorys * problem.num_stages * problem.num_reentrances * problem.num_jobs / 1000

    @classmethod
    def read_parameter(cls):
        return {
            k: v
            for k, v in cls.__dict__.items()
            if not k.startswith("_") and not callable(v)
        }


class Config2:
    # 需要调的参数
    main_speed_task_size = 50
    low_speed_task_size = 20
    high_speed_task_size = 20
    middle_speed_task_size = 20
    radius = 0.1
    q_alpha = 0.20
    q_gamma = 0.70

    crossover_prob = 0.8
    mutation_prob = 0.2
    g_time = None
    # Q-learning 参数
    q_epsilon_start = 1.0
    q_epsilon_min = 0.10

    @classmethod
    def update_from_problem(cls, problem, file_path):
        scale = os.path.basename(os.path.dirname(file_path))
        cls.g_time = 30 * problem.num_factorys * problem.num_stages * problem.num_reentrances * problem.num_jobs / 1000

    @classmethod
    def read_parameter(cls):
        return {
            k: v
            for k, v in cls.__dict__.items()
            if not k.startswith("_") and not callable(v)
        }


class Config3:
    # 需要调的参数
    main_speed_task_size = 50
    low_speed_task_size = 25
    high_speed_task_size = 25
    middle_speed_task_size = 25
    radius = 0.15
    q_alpha = 0.30
    q_gamma = 0.80

    crossover_prob = 0.8
    mutation_prob = 0.2
    g_time = None
    # Q-learning 参数
    q_epsilon_start = 1.0
    q_epsilon_min = 0.10

    @classmethod
    def update_from_problem(cls, problem, file_path):
        scale = os.path.basename(os.path.dirname(file_path))
        cls.g_time = 30 * problem.num_factorys * problem.num_stages * problem.num_reentrances * problem.num_jobs / 1000

    @classmethod
    def read_parameter(cls):
        return {
            k: v
            for k, v in cls.__dict__.items()
            if not k.startswith("_") and not callable(v)
        }


class Config4:
    # 需要调的参数
    main_speed_task_size = 50
    low_speed_task_size = 30
    high_speed_task_size = 30
    middle_speed_task_size = 30
    radius = 0.20
    q_alpha = 0.40
    q_gamma = 0.90

    crossover_prob = 0.8
    mutation_prob = 0.2
    g_time = None
    # Q-learning 参数
    q_epsilon_start = 1.0
    q_epsilon_min = 0.10

    @classmethod
    def update_from_problem(cls, problem, file_path):
        scale = os.path.basename(os.path.dirname(file_path))
        cls.g_time = 30 * problem.num_factorys * problem.num_stages * problem.num_reentrances * problem.num_jobs / 1000

    @classmethod
    def read_parameter(cls):
        return {
            k: v
            for k, v in cls.__dict__.items()
            if not k.startswith("_") and not callable(v)
        }


class Config5:
    # 需要调的参数
    main_speed_task_size = 100
    low_speed_task_size = 15
    high_speed_task_size = 15
    middle_speed_task_size = 15
    radius = 0.10
    q_alpha = 0.30
    q_gamma = 0.90

    crossover_prob = 0.8
    mutation_prob = 0.2
    g_time = None
    # Q-learning 参数
    q_epsilon_start = 1.0
    q_epsilon_min = 0.10

    @classmethod
    def update_from_problem(cls, problem, file_path):
        scale = os.path.basename(os.path.dirname(file_path))
        cls.g_time = 30 * problem.num_factorys * problem.num_stages * problem.num_reentrances * problem.num_jobs / 1000

    @classmethod
    def read_parameter(cls):
        return {
            k: v
            for k, v in cls.__dict__.items()
            if not k.startswith("_") and not callable(v)
        }


class Config6:
    # 需要调的参数
    main_speed_task_size = 100
    low_speed_task_size = 20
    high_speed_task_size = 20
    middle_speed_task_size = 20
    radius = 0.05
    q_alpha = 0.40
    q_gamma = 0.80

    crossover_prob = 0.8
    mutation_prob = 0.2
    g_time = None
    # Q-learning 参数
    q_epsilon_start = 1.0
    q_epsilon_min = 0.10

    @classmethod
    def update_from_problem(cls, problem, file_path):
        scale = os.path.basename(os.path.dirname(file_path))
        cls.g_time = 30 * problem.num_factorys * problem.num_stages * problem.num_reentrances * problem.num_jobs / 1000

    @classmethod
    def read_parameter(cls):
        return {
            k: v
            for k, v in cls.__dict__.items()
            if not k.startswith("_") and not callable(v)
        }


class Config7:
    # 需要调的参数
    main_speed_task_size = 100
    low_speed_task_size = 25
    high_speed_task_size = 25
    middle_speed_task_size = 25
    radius = 0.20
    q_alpha = 0.10
    q_gamma = 0.70

    crossover_prob = 0.8
    mutation_prob = 0.2
    g_time = None
    # Q-learning 参数
    q_epsilon_start = 1.0
    q_epsilon_min = 0.10

    @classmethod
    def update_from_problem(cls, problem, file_path):
        scale = os.path.basename(os.path.dirname(file_path))
        cls.g_time = 30 * problem.num_factorys * problem.num_stages * problem.num_reentrances * problem.num_jobs / 1000

    @classmethod
    def read_parameter(cls):
        return {
            k: v
            for k, v in cls.__dict__.items()
            if not k.startswith("_") and not callable(v)
        }


class Config8:
    # 需要调的参数
    main_speed_task_size = 100
    low_speed_task_size = 30
    high_speed_task_size = 30
    middle_speed_task_size = 30
    radius = 0.15
    q_alpha = 0.20
    q_gamma = 0.60

    crossover_prob = 0.8
    mutation_prob = 0.2
    g_time = None
    # Q-learning 参数
    q_epsilon_start = 1.0
    q_epsilon_min = 0.10

    @classmethod
    def update_from_problem(cls, problem, file_path):
        scale = os.path.basename(os.path.dirname(file_path))
        cls.g_time = 30 * problem.num_factorys * problem.num_stages * problem.num_reentrances * problem.num_jobs / 1000

    @classmethod
    def read_parameter(cls):
        return {
            k: v
            for k, v in cls.__dict__.items()
            if not k.startswith("_") and not callable(v)
        }


class Config9:
    # 需要调的参数
    main_speed_task_size = 150
    low_speed_task_size = 15
    high_speed_task_size = 15
    middle_speed_task_size = 15
    radius = 0.15
    q_alpha = 0.40
    q_gamma = 0.70

    crossover_prob = 0.8
    mutation_prob = 0.2
    g_time = None
    # Q-learning 参数
    q_epsilon_start = 1.0
    q_epsilon_min = 0.10

    @classmethod
    def update_from_problem(cls, problem, file_path):
        scale = os.path.basename(os.path.dirname(file_path))
        cls.g_time = 30 * problem.num_factorys * problem.num_stages * problem.num_reentrances * problem.num_jobs / 1000

    @classmethod
    def read_parameter(cls):
        return {
            k: v
            for k, v in cls.__dict__.items()
            if not k.startswith("_") and not callable(v)
        }


class Config10:
    # 需要调的参数
    main_speed_task_size = 150
    low_speed_task_size = 20
    high_speed_task_size = 20
    middle_speed_task_size = 20
    radius = 0.20
    q_alpha = 0.30
    q_gamma = 0.60

    crossover_prob = 0.8
    mutation_prob = 0.2
    g_time = None
    # Q-learning 参数
    q_epsilon_start = 1.0
    q_epsilon_min = 0.10

    @classmethod
    def update_from_problem(cls, problem, file_path):
        scale = os.path.basename(os.path.dirname(file_path))
        cls.g_time = 30 * problem.num_factorys * problem.num_stages * problem.num_reentrances * problem.num_jobs / 1000

    @classmethod
    def read_parameter(cls):
        return {
            k: v
            for k, v in cls.__dict__.items()
            if not k.startswith("_") and not callable(v)
        }


class Config11:
    # 需要调的参数
    main_speed_task_size = 150
    low_speed_task_size = 25
    high_speed_task_size = 25
    middle_speed_task_size = 25
    radius = 0.05
    q_alpha = 0.20
    q_gamma = 0.90

    crossover_prob = 0.8
    mutation_prob = 0.2
    g_time = None
    # Q-learning 参数
    q_epsilon_start = 1.0
    q_epsilon_min = 0.10

    @classmethod
    def update_from_problem(cls, problem, file_path):
        scale = os.path.basename(os.path.dirname(file_path))
        cls.g_time = 30 * problem.num_factorys * problem.num_stages * problem.num_reentrances * problem.num_jobs / 1000

    @classmethod
    def read_parameter(cls):
        return {
            k: v
            for k, v in cls.__dict__.items()
            if not k.startswith("_") and not callable(v)
        }


class Config12:
    # 需要调的参数
    main_speed_task_size = 150
    low_speed_task_size = 30
    high_speed_task_size = 30
    middle_speed_task_size = 30
    radius = 0.10
    q_alpha = 0.10
    q_gamma = 0.80

    crossover_prob = 0.8
    mutation_prob = 0.2
    g_time = None
    # Q-learning 参数
    q_epsilon_start = 1.0
    q_epsilon_min = 0.10

    @classmethod
    def update_from_problem(cls, problem, file_path):
        scale = os.path.basename(os.path.dirname(file_path))
        cls.g_time = 30 * problem.num_factorys * problem.num_stages * problem.num_reentrances * problem.num_jobs / 1000

    @classmethod
    def read_parameter(cls):
        return {
            k: v
            for k, v in cls.__dict__.items()
            if not k.startswith("_") and not callable(v)
        }


class Config13:
    # 需要调的参数
    main_speed_task_size = 200
    low_speed_task_size = 15
    high_speed_task_size = 15
    middle_speed_task_size = 15
    radius = 0.20
    q_alpha = 0.20
    q_gamma = 0.80

    crossover_prob = 0.8
    mutation_prob = 0.2
    g_time = None
    # Q-learning 参数
    q_epsilon_start = 1.0
    q_epsilon_min = 0.10

    @classmethod
    def update_from_problem(cls, problem, file_path):
        scale = os.path.basename(os.path.dirname(file_path))
        cls.g_time = 30 * problem.num_factorys * problem.num_stages * problem.num_reentrances * problem.num_jobs / 1000

    @classmethod
    def read_parameter(cls):
        return {
            k: v
            for k, v in cls.__dict__.items()
            if not k.startswith("_") and not callable(v)
        }


class Config14:
    # 需要调的参数
    main_speed_task_size = 200
    low_speed_task_size = 20
    high_speed_task_size = 20
    middle_speed_task_size = 20
    radius = 0.15
    q_alpha = 0.10
    q_gamma = 0.90

    crossover_prob = 0.8
    mutation_prob = 0.2
    g_time = None
    # Q-learning 参数
    q_epsilon_start = 1.0
    q_epsilon_min = 0.10

    @classmethod
    def update_from_problem(cls, problem, file_path):
        scale = os.path.basename(os.path.dirname(file_path))
        cls.g_time = 30 * problem.num_factorys * problem.num_stages * problem.num_reentrances * problem.num_jobs / 1000

    @classmethod
    def read_parameter(cls):
        return {
            k: v
            for k, v in cls.__dict__.items()
            if not k.startswith("_") and not callable(v)
        }


class Config15:
    # 需要调的参数
    main_speed_task_size = 200
    low_speed_task_size = 25
    high_speed_task_size = 25
    middle_speed_task_size = 25
    radius = 0.10
    q_alpha = 0.40
    q_gamma = 0.60

    crossover_prob = 0.8
    mutation_prob = 0.2
    g_time = None
    # Q-learning 参数
    q_epsilon_start = 1.0
    q_epsilon_min = 0.10

    @classmethod
    def update_from_problem(cls, problem, file_path):
        scale = os.path.basename(os.path.dirname(file_path))
        cls.g_time = 30 * problem.num_factorys * problem.num_stages * problem.num_reentrances * problem.num_jobs / 1000

    @classmethod
    def read_parameter(cls):
        return {
            k: v
            for k, v in cls.__dict__.items()
            if not k.startswith("_") and not callable(v)
        }


class Config16:
    # 需要调的参数
    main_speed_task_size = 200
    low_speed_task_size = 30
    high_speed_task_size = 30
    middle_speed_task_size = 30
    radius = 0.05
    q_alpha = 0.30
    q_gamma = 0.70

    crossover_prob = 0.8
    mutation_prob = 0.2
    g_time = None
    # Q-learning 参数
    q_epsilon_start = 1.0
    q_epsilon_min = 0.10

    @classmethod
    def update_from_problem(cls, problem, file_path):
        scale = os.path.basename(os.path.dirname(file_path))
        cls.g_time = 30 * problem.num_factorys * problem.num_stages * problem.num_reentrances * problem.num_jobs / 1000

    @classmethod
    def read_parameter(cls):
        return {
            k: v
            for k, v in cls.__dict__.items()
            if not k.startswith("_") and not callable(v)
        }