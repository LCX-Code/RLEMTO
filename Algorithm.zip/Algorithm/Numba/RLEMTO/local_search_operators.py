import random

import numpy as np

from Algorithm.Numba.RLEMTO.decode import decode, decode_batch
from Algorithm.Numba.RLEMTO.Solution import Solution

try:
    from numba import njit
except ImportError:  # pragma: no cover
    njit = None

_ORDERED_SPEED_LEVELS_CACHE = {}
_SPEED_INDEX_CACHE = {}
_TASK_SPEED_LEVELS_CACHE = {}
_TASK_SPEED_INDEX_CACHE = {}
_TASK_SPEED_BOUNDS_CACHE = {}
_PROBLEM_INFO_CACHE = {}
_PROBLEM_ARRAYS_CACHE = {}
_VALID_SPEED_LEVELS_CACHE = {}
_SPEED_LOOKUP_CACHE = {}
DEBUG_VALIDATE = False

def _safe_speed_level(speed_vector, lap, job, stage):
    if lap < 0 or lap >= len(speed_vector):
        return None
    lap_data = speed_vector[lap]
    if job < 0 or job >= len(lap_data):
        return None
    job_data = lap_data[job]
    if stage < 0 or stage >= len(job_data):
        return None
    return job_data[stage]


def _validate_speed_vector_shape(problem, speed_vector):
    info = _problem_info(problem)
    num_laps = info["num_laps"]
    num_jobs = info["num_jobs"]
    num_stages = info["num_stages"]

    if len(speed_vector) != num_laps:
        raise ValueError(
            f"Invalid speed_vector lap size: expected {num_laps}, got {len(speed_vector)}."
        )

    for lap_idx, lap_data in enumerate(speed_vector):
        if len(lap_data) != num_jobs:
            raise ValueError(
                f"Invalid speed_vector job size at lap {lap_idx}: "
                f"expected {num_jobs}, got {len(lap_data)}."
            )
        for job_idx, job_data in enumerate(lap_data):
            if len(job_data) != num_stages:
                raise ValueError(
                    f"Invalid speed_vector stage size at (lap={lap_idx}, job={job_idx}): "
                    f"expected {num_stages}, got {len(job_data)}."
                )


def _validate_speed_vector(problem, speed_vector):
    _validate_speed_vector_shape(problem, speed_vector)
    _validate_speed_vector_levels(problem, speed_vector)


def _run_decode_with_cp_core(problem, job_sequence, factory_assignment, speed_vector):
    info = _problem_info(problem)
    arrays = _problem_arrays(problem)
    if DEBUG_VALIDATE:
        _validate_speed_vector(problem, speed_vector)

    scheduled_jobs = np.asarray(job_sequence, dtype=np.int64)
    factory_assignment = np.asarray(factory_assignment, dtype=np.int64)
    speed_vector = np.asarray(speed_vector, dtype=np.int64)

    return _decode_with_cp_core(
        scheduled_jobs,
        scheduled_jobs.size,
        factory_assignment,
        speed_vector,
        info["num_factories"],
        info["num_jobs"],
        info["num_stages"],
        info["num_laps"],
        arrays["max_machines"],
        arrays["num_machines_per_stage"],
        arrays["processing_times"],
        arrays["due_dates"],
        arrays["penalty_factors"],
        arrays["speed_lookup"],
        float(problem.unit_idle_power),
    ), scheduled_jobs

def _build_solution_key(job_sequence, factory_assignment, speed_vector):
    speed_key = tuple(
        tuple(tuple(job_speeds) for job_speeds in lap)
        for lap in speed_vector
    )
    return (
        tuple(job_sequence),
        tuple(factory_assignment),
        speed_key,
    )

def _random_feasible_speed_position(problem, speed_vector, task_name, for_speedup=True):
    min_level = _task_min_speed_level(problem, task_name)
    max_level = _task_max_speed_level(problem, task_name)

    chosen = None
    count = 0

    for lap, lap_data in enumerate(speed_vector):
        for job, job_speeds in enumerate(lap_data):
            for stage, speed in enumerate(job_speeds):
                if for_speedup:
                    if min_level <= speed < max_level:
                        count += 1
                        if random.randrange(count) == 0:
                            chosen = (lap, job, stage)
                else:
                    if min_level < speed <= max_level:
                        count += 1
                        if random.randrange(count) == 0:
                            chosen = (lap, job, stage)

    return chosen

def _solution_key(individual):
    cached_key = getattr(individual, "cached_key", None)
    if cached_key is not None:
        return cached_key

    cached_key = _build_solution_key(
        individual.job_sequence,
        individual.factory_assignment,
        individual.speed_vector,
    )
    individual.cached_key = cached_key
    return cached_key

def _finalize_child(child):
    child.cached_key = _build_solution_key(
        child.job_sequence,
        child.factory_assignment,
        child.speed_vector,
    )
    _clear_analysis_cache(child)
    return child


def batch_decode_and_cache(problem, individuals):
    if not individuals:
        return []

    if DEBUG_VALIDATE:
        for idx, ind in enumerate(individuals):
            try:
                _validate_speed_vector(problem, ind.speed_vector)
            except ValueError as exc:
                raise ValueError(
                    f"Invalid speed_vector in individual {idx}: {exc}"
                ) from exc

    job_sequences = [ind.job_sequence for ind in individuals]
    seq_lengths = [len(ind.job_sequence) for ind in individuals]
    factory_assignments = [ind.factory_assignment for ind in individuals]
    speed_vectors = [ind.speed_vector for ind in individuals]

    makespans, twts, tecs, completion_times = decode_batch(
        problem,
        job_sequences,
        seq_lengths,
        factory_assignments,
        speed_vectors,
    )

    for idx, ind in enumerate(individuals):
        ind.makespan = float(makespans[idx])
        ind.TWT = float(twts[idx])
        ind.TEC = float(tecs[idx])
        if completion_times is not None:
            ind.completion_times = completion_times[idx].tolist()
        else:
            ind.completion_times = None
        ind.cached_key = _build_solution_key(
            ind.job_sequence,
            ind.factory_assignment,
            ind.speed_vector,
        )
        _clear_analysis_cache(ind)

    return individuals


def _problem_info(problem):
    cache_key = problem
    cached = _PROBLEM_INFO_CACHE.get(cache_key)
    if cached is not None:
        return cached

    info = problem.info
    if len(info) == 11:
        (
            num_speed_levels,
            num_factories,
            num_jobs,
            num_stages,
            num_laps,
            num_machines_per_stage,
            processing_times,
            due_dates,
            speed_levels,
            priorities,
            penalty_factors,
        ) = info
    else:
        (
            num_factories,
            num_jobs,
            num_stages,
            num_laps,
            num_machines_per_stage,
            processing_times,
            due_dates,
            speed_levels,
            priorities,
            penalty_factors,
        ) = info
        num_speed_levels = len(speed_levels)

    cached = {
        "num_speed_levels": num_speed_levels,
        "num_factories": num_factories,
        "num_jobs": num_jobs,
        "num_stages": num_stages,
        "num_laps": num_laps,
        "num_machines_per_stage": num_machines_per_stage,
        "processing_times": processing_times,
        "due_dates": due_dates,
        "speed_levels": speed_levels,
        "priorities": priorities,
        "penalty_factors": penalty_factors,
    }
    _PROBLEM_INFO_CACHE[cache_key] = cached
    return cached


def _split_task_speed_levels(problem):
    speed_candidates = tuple(sorted(_problem_info(problem)["speed_levels"].keys()))
    q = len(speed_candidates)
    k, r = divmod(q, 3)

    if r == 0:
        low_size, middle_size, high_size = k, k, k
    elif r == 1:
        low_size, middle_size, high_size = k, k + 1, k
    else:
        low_size, middle_size, high_size = k + 1, k, k + 1

    low_end = low_size
    middle_end = low_end + middle_size

    groups = {
        "low": speed_candidates[:low_end],
        "middle": speed_candidates[low_end:middle_end],
        "high": speed_candidates[middle_end:],
        "main": speed_candidates,
    }

    for task_name in ("low", "middle", "high"):
        if not groups[task_name]:
            raise ValueError(
                f"Speed group '{task_name}' is empty. Current speed levels: {speed_candidates}"
            )

    return groups


def _build_speed_lookup(speed_levels):
    max_level = max(speed_levels.keys())
    lookup = np.zeros(max_level + 1, dtype=np.float64)
    for level, speed in speed_levels.items():
        lookup[level] = speed
    return lookup


def _speed_lookup(problem):
    cache_key = problem
    lookup = _SPEED_LOOKUP_CACHE.get(cache_key)
    if lookup is None:
        lookup = _build_speed_lookup(_problem_info(problem)["speed_levels"])
        _SPEED_LOOKUP_CACHE[cache_key] = lookup
    return lookup


def _valid_speed_levels(problem):
    cache_key = problem
    valid_levels = _VALID_SPEED_LEVELS_CACHE.get(cache_key)
    if valid_levels is None:
        valid_levels = frozenset(_problem_info(problem)["speed_levels"].keys())
        _VALID_SPEED_LEVELS_CACHE[cache_key] = valid_levels
    return valid_levels


def _validate_speed_vector_levels(problem, speed_vector):
    valid_levels = _valid_speed_levels(problem)

    for lap_idx, lap in enumerate(speed_vector):
        for job_idx, job_speeds in enumerate(lap):
            for stage_idx, level in enumerate(job_speeds):
                if level not in valid_levels:
                    raise ValueError(
                        f"Invalid speed level {level} at (lap={lap_idx}, job={job_idx}, stage={stage_idx}). "
                        f"Valid levels are {sorted(valid_levels)}."
                    )


def _problem_arrays(problem):
    cache_key = problem
    cached = _PROBLEM_ARRAYS_CACHE.get(cache_key)
    if cached is not None:
        return cached

    info = _problem_info(problem)
    num_machines_per_stage = np.asarray(info["num_machines_per_stage"], dtype=np.int64)
    cached = {
        "num_machines_per_stage": num_machines_per_stage,
        "processing_times": np.asarray(info["processing_times"], dtype=np.float64),
        "due_dates": np.asarray(info["due_dates"], dtype=np.float64),
        "penalty_factors": np.asarray(info["penalty_factors"], dtype=np.float64),
        "speed_lookup": _speed_lookup(problem),
        "max_machines": int(num_machines_per_stage.max()),
    }
    _PROBLEM_ARRAYS_CACHE[cache_key] = cached
    return cached


if njit is not None:
    @njit(cache=True)
    def _op_id(factory, lap, job, stage, num_laps, num_jobs, num_stages):
        return (((factory * num_laps + lap) * num_jobs + job) * num_stages + stage)


    @njit(cache=True)
    def _sort_jobs_by_values_inplace(jobs, values, length):
        for i in range(length - 1):
            min_pos = i
            min_job = jobs[i]
            min_val = values[min_job]
            for j in range(i + 1, length):
                job = jobs[j]
                val = values[job]
                if val < min_val:
                    min_val = val
                    min_job = job
                    min_pos = j
            if min_pos != i:
                jobs[i], jobs[min_pos] = jobs[min_pos], jobs[i]


    @njit(cache=True)
    def _decode_with_cp_core(
        job_sequence,
        seq_length,
        factory_assignment,
        speed_vector,
        num_factories,
        num_jobs,
        num_stages,
        num_laps,
        max_machines,
        num_machines_per_stage,
        processing_times,
        due_dates,
        penalty_factors,
        speed_lookup,
        unit_idle_power,
    ):
        total_ops = num_factories * num_laps * num_jobs * num_stages

        c_times = np.zeros((num_factories, num_laps, num_jobs, num_stages), dtype=np.float64)
        machine_ready_times = np.zeros((num_factories, num_stages, max_machines), dtype=np.float64)
        machine_loads = np.zeros((num_factories, num_stages, max_machines), dtype=np.float64)
        machine_processing_energy = np.zeros((num_factories, num_stages, max_machines), dtype=np.float64)
        machine_idle_energy = np.zeros((num_factories, num_stages, max_machines), dtype=np.float64)

        first_lap_jobs_by_factory = np.full((num_factories, num_jobs), -1, dtype=np.int64)
        first_lap_counts = np.zeros(num_factories, dtype=np.int64)

        lap_sequence = np.empty(num_jobs, dtype=np.int64)
        stage_sequence = np.empty(num_jobs, dtype=np.int64)

        active_mask = np.zeros(total_ops, dtype=np.uint8)
        op_start = np.zeros(total_ops, dtype=np.float64)
        op_end = np.zeros(total_ops, dtype=np.float64)
        op_proc = np.zeros(total_ops, dtype=np.float64)
        op_machine = np.full(total_ops, -1, dtype=np.int64)
        machine_pred = np.full(total_ops, -1, dtype=np.int64)
        machine_succ = np.full(total_ops, -1, dtype=np.int64)

        machine_last_op = np.full((num_factories, num_stages, max_machines), -1, dtype=np.int64)

        for idx in range(seq_length):
            job = job_sequence[idx]
            factory = factory_assignment[job]
            pos = first_lap_counts[factory]
            first_lap_jobs_by_factory[factory, pos] = job
            first_lap_counts[factory] += 1

        for factory in range(num_factories):
            length = first_lap_counts[factory]
            for i in range(length):
                lap_sequence[i] = first_lap_jobs_by_factory[factory, i]

            for lap in range(num_laps):
                if lap > 0:
                    prev_last_stage = c_times[factory, lap - 1, :, num_stages - 1]
                    _sort_jobs_by_values_inplace(lap_sequence, prev_last_stage, length)

                for i in range(length):
                    stage_sequence[i] = lap_sequence[i]

                for stage in range(num_stages):
                    if stage > 0:
                        prev_stage_ct = c_times[factory, lap, :, stage - 1]
                        _sort_jobs_by_values_inplace(stage_sequence, prev_stage_ct, length)

                    machine_count = num_machines_per_stage[stage]

                    for i in range(length):
                        job = stage_sequence[i]

                        if lap == 0 and stage == 0:
                            job_ready_time = 0.0
                        elif stage == 0:
                            job_ready_time = c_times[factory, lap - 1, job, num_stages - 1]
                        else:
                            job_ready_time = c_times[factory, lap, job, stage - 1]

                        speed_level = speed_vector[lap, job, stage]
                        speed = speed_lookup[speed_level]
                        p_time = processing_times[job, stage, lap] / speed
                        unit_processing_power = 4.0 * speed * speed

                        best_machine = 0
                        best_finish = 1e30
                        best_ready = 1e30
                        best_load = 1e30

                        for m in range(machine_count):
                            machine_ready = machine_ready_times[factory, stage, m]
                            start_time = machine_ready if machine_ready > job_ready_time else job_ready_time
                            finish_time = start_time + p_time
                            load = machine_loads[factory, stage, m]

                            if (
                                finish_time < best_finish
                                or (finish_time == best_finish and machine_ready < best_ready)
                                or (finish_time == best_finish and machine_ready == best_ready and load < best_load)
                            ):
                                best_finish = finish_time
                                best_ready = machine_ready
                                best_load = load
                                best_machine = m

                        machine_ready = machine_ready_times[factory, stage, best_machine]
                        start_time = machine_ready if machine_ready > job_ready_time else job_ready_time
                        end_time = start_time + p_time
                        idle_time = start_time - machine_ready

                        machine_processing_energy[factory, stage, best_machine] += p_time * unit_processing_power
                        machine_idle_energy[factory, stage, best_machine] += idle_time * unit_idle_power

                        c_times[factory, lap, job, stage] = end_time
                        machine_ready_times[factory, stage, best_machine] = end_time
                        machine_loads[factory, stage, best_machine] += p_time

                        oid = _op_id(factory, lap, job, stage, num_laps, num_jobs, num_stages)
                        pred = machine_last_op[factory, stage, best_machine]

                        active_mask[oid] = 1
                        op_start[oid] = start_time
                        op_end[oid] = end_time
                        op_proc[oid] = p_time
                        op_machine[oid] = best_machine
                        machine_pred[oid] = pred

                        if pred != -1:
                            machine_succ[pred] = oid

                        machine_last_op[factory, stage, best_machine] = oid

        last_lap = num_laps - 1
        last_stage = num_stages - 1

        makespan = 0.0
        twt = 0.0
        completion_times = np.zeros(num_jobs, dtype=np.float64)
        job_weighted_tardiness = np.zeros(num_jobs, dtype=np.float64)

        for idx in range(seq_length):
            job = job_sequence[idx]
            factory = factory_assignment[job]
            completion = c_times[factory, last_lap, job, last_stage]
            completion_times[job] = completion

            if completion > makespan:
                makespan = completion

            tardiness = completion - due_dates[job]
            if tardiness > 0.0:
                wt = tardiness * penalty_factors[job]
                twt += wt
                job_weighted_tardiness[job] = wt

        tec = 0.0
        for factory in range(num_factories):
            for stage in range(num_stages):
                machine_count = num_machines_per_stage[stage]
                for m in range(machine_count):
                    tec += machine_processing_energy[factory, stage, m]
                    tec += machine_idle_energy[factory, stage, m]

        return (
            makespan,
            twt,
            tec,
            completion_times,
            job_weighted_tardiness,
            active_mask,
            op_start,
            op_end,
            op_proc,
            op_machine,
            machine_pred,
            machine_succ,
        )



def _decode_op_id(op_id, num_laps, num_jobs, num_stages):
    stage = op_id % num_stages
    x = op_id // num_stages
    job = x % num_jobs
    x //= num_jobs
    lap = x % num_laps
    factory = x // num_laps
    return factory, lap, job, stage


# def decode_with_critical_mask(problem, job_sequence, factory_assignment, speed_vector):
#     if njit is None:
#         raise ImportError("decode_with_critical_mask needs numba: pip install numba")
#
#     info = _problem_info(problem)
#     num_jobs = info["num_jobs"]
#
#     scheduled_jobs = np.asarray(job_sequence, dtype=np.int64)
#     if scheduled_jobs.size == 0:
#         return {
#             "makespan": 0.0,
#             "twt": 0.0,
#             "tec": 0.0,
#             "completion_times": [0.0 for _ in range(num_jobs)],
#             "job_weighted_tardiness": [0.0 for _ in range(num_jobs)],
#             "critical_ops": [],
#             "noncritical_ops": [],
#             "op_start": {},
#             "op_end": {},
#             "op_proc": {},
#         }
#
#     result, scheduled_jobs = _run_decode_with_cp_core(problem, job_sequence, factory_assignment, speed_vector)
#
#     (
#         makespan,
#         twt,
#         tec,
#         completion_times_np,
#         job_weighted_tardiness_np,
#         active_mask,
#         op_start,
#         op_end,
#         op_proc,
#         op_machine,
#         machine_pred,
#         machine_succ,
#     ) = result
#
#     active_op_ids = np.flatnonzero(active_mask)
#
#     successors = {}
#     latest_start = {}
#     critical_ops = []
#     noncritical_ops = []
#     start_map = {}
#     end_map = {}
#     proc_map = {}
#
#     op_list = []
#     for oid in active_op_ids:
#         factory, lap, job, stage = _decode_op_id(
#             int(oid), info["num_laps"], info["num_jobs"], info["num_stages"]
#         )
#         op = (factory, lap, job, stage)
#         op_list.append((op, int(oid)))
#         successors[op] = []
#         start_map[op] = float(op_start[oid])
#         end_map[op] = float(op_end[oid])
#         proc_map[op] = float(op_proc[oid])
#
#     for op, oid in op_list:
#         mp_id = int(machine_succ[oid])
#         if mp_id != -1:
#             successors[op].append(
#                 _decode_op_id(mp_id, info["num_laps"], info["num_jobs"], info["num_stages"])
#             )
#
#         factory, lap, job, stage = op
#         if stage < info["num_stages"] - 1:
#             successors[op].append((factory, lap, job, stage + 1))
#         elif lap < info["num_laps"] - 1:
#             successors[op].append((factory, lap + 1, job, 0))
#
#     sorted_ops_desc = sorted(op_list, key=lambda item: end_map[item[0]], reverse=True)
#     eps_cp = 1e-9
#     for op, oid in sorted_ops_desc:
#         succs = successors[op]
#         p_time = proc_map[op]
#         lf = min(latest_start[s] for s in succs) if succs else makespan
#         latest_start[op] = lf - p_time
#
#     for op, oid in op_list:
#         slack = latest_start[op] - start_map[op]
#         if abs(slack) <= eps_cp:
#             critical_ops.append(op)
#         else:
#             noncritical_ops.append(op)
#
#     return {
#         "makespan": float(makespan),
#         "twt": float(twt),
#         "tec": float(tec),
#         "completion_times": completion_times_np.tolist(),
#         "job_weighted_tardiness": job_weighted_tardiness_np.tolist(),
#         "critical_ops": critical_ops,
#         "noncritical_ops": noncritical_ops,
#         "op_start": start_map,
#         "op_end": end_map,
#         "op_proc": proc_map,
#     }
def decode_with_critical_mask(problem, job_sequence, factory_assignment, speed_vector):
    if njit is None:
        raise ImportError(
            "decode_with_critical_mask needs numba: pip install numba"
        )

    info = _problem_info(problem)
    num_jobs = info["num_jobs"]

    scheduled_jobs = np.asarray(job_sequence, dtype=np.int64)

    if scheduled_jobs.size == 0:
        return {
            "makespan": 0.0,
            "twt": 0.0,
            "tec": 0.0,
            "completion_times": [0.0 for _ in range(num_jobs)],
            "job_weighted_tardiness": [0.0 for _ in range(num_jobs)],
            "critical_ops": [],
            "noncritical_ops": [],
            "op_start": {},
            "op_end": {},
            "op_proc": {},
        }

    result, scheduled_jobs = _run_decode_with_cp_core(
        problem,
        job_sequence,
        factory_assignment,
        speed_vector,
    )

    (
        makespan,
        twt,
        tec,
        completion_times_np,
        job_weighted_tardiness_np,
        active_mask,
        op_start,
        op_end,
        op_proc,
        op_machine,
        machine_pred,
        machine_succ,
    ) = result

    active_op_ids = np.flatnonzero(active_mask)

    successors = {}
    start_map = {}
    end_map = {}
    proc_map = {}
    op_list = []

    # 建立所有有效操作
    for oid in active_op_ids:
        oid = int(oid)

        factory, lap, job, stage = _decode_op_id(
            oid,
            info["num_laps"],
            info["num_jobs"],
            info["num_stages"],
        )

        op = (factory, lap, job, stage)

        op_list.append((op, oid))
        successors[op] = []
        start_map[op] = float(op_start[oid])
        end_map[op] = float(op_end[oid])
        proc_map[op] = float(op_proc[oid])

    operation_set = set(start_map.keys())

    # 建立机器后继关系和作业工艺后继关系
    for op, oid in op_list:
        machine_successor_id = int(machine_succ[oid])

        if machine_successor_id != -1:
            machine_successor = _decode_op_id(
                machine_successor_id,
                info["num_laps"],
                info["num_jobs"],
                info["num_stages"],
            )
            successors[op].append(machine_successor)

        factory, lap, job, stage = op

        # 同一作业的下一阶段
        if stage < info["num_stages"] - 1:
            successors[op].append(
                (factory, lap, job, stage + 1)
            )

        # 当前重入结束后进入下一次重入
        elif lap < info["num_laps"] - 1:
            successors[op].append(
                (factory, lap + 1, job, 0)
            )

    # 删除重复后继
    for op in successors:
        successors[op] = list(dict.fromkeys(successors[op]))

    # 检查后继是否都存在
    missing_successors = {
        successor
        for succs in successors.values()
        for successor in succs
        if successor not in operation_set
    }

    if missing_successors:
        raise ValueError(
            "The precedence graph contains missing successor operations: "
            f"{sorted(missing_successors)[:10]}"
        )

    # 建立反向邻接表：
    # predecessors[successor] = all predecessors of successor
    predecessors = {
        op: []
        for op in operation_set
    }

    remaining_successor_count = {}

    for op in operation_set:
        succs = successors[op]
        remaining_successor_count[op] = len(succs)

        for successor in succs:
            predecessors[successor].append(op)

    # 从没有后继的末端操作开始反向拓扑计算
    queue = [
        op
        for op in operation_set
        if remaining_successor_count[op] == 0
    ]

    latest_start = {}
    latest_finish = {}

    queue_index = 0

    while queue_index < len(queue):
        op = queue[queue_index]
        queue_index += 1

        succs = successors[op]

        if succs:
            latest_finish[op] = min(
                latest_start[successor]
                for successor in succs
            )
        else:
            latest_finish[op] = float(makespan)

        latest_start[op] = (
            latest_finish[op] - proc_map[op]
        )

        # 当前操作已经计算完成，
        # 通知它的前驱操作减少一个未完成后继
        for predecessor in predecessors[op]:
            remaining_successor_count[predecessor] -= 1

            if remaining_successor_count[predecessor] == 0:
                queue.append(predecessor)

    # 如果没有处理完所有操作，说明图中存在环
    if len(latest_start) != len(operation_set):
        unresolved = [
            op
            for op in operation_set
            if op not in latest_start
        ]

        raise ValueError(
            "The operation graph contains a cycle or invalid "
            "precedence relations. Unresolved operations: "
            f"{unresolved[:10]}"
        )

    # 根据总时差识别关键操作和非关键操作
    critical_ops = []
    noncritical_ops = []
    eps_cp = 1e-9

    for op, oid in op_list:
        slack = latest_start[op] - start_map[op]

        if abs(slack) <= eps_cp:
            critical_ops.append(op)
        else:
            noncritical_ops.append(op)

    return {
        "makespan": float(makespan),
        "twt": float(twt),
        "tec": float(tec),
        "completion_times": completion_times_np.tolist(),
        "job_weighted_tardiness": (
            job_weighted_tardiness_np.tolist()
        ),
        "critical_ops": critical_ops,
        "noncritical_ops": noncritical_ops,
        "op_start": start_map,
        "op_end": end_map,
        "op_proc": proc_map,
    }

# def decode_with_critical_path(problem, job_sequence, factory_assignment, speed_vector, return_details=False):
#     if njit is None:
#         raise ImportError("decode_with_critical_path needs numba: pip install numba")
#
#     info = _problem_info(problem)
#     num_jobs = info["num_jobs"]
#
#     scheduled_jobs = np.asarray(job_sequence, dtype=np.int64)
#     if scheduled_jobs.size == 0:
#         if return_details:
#             return 0.0, 0.0, 0.0, {
#                 "completion_times": [0.0 for _ in range(num_jobs)],
#                 "job_weighted_tardiness": [0.0 for _ in range(num_jobs)],
#                 "scheduled_jobs": [],
#                 "critical_operations": set(),
#                 "operation_slacks": {},
#                 "operation_info": {},
#                 "latest_start": {},
#                 "latest_finish": {},
#                 "successors": {},
#             }
#         return 0.0, 0.0, 0.0
#
#     result, scheduled_jobs = _run_decode_with_cp_core(problem, job_sequence, factory_assignment, speed_vector)
#
#     (
#         makespan,
#         twt,
#         tec,
#         completion_times_np,
#         job_weighted_tardiness_np,
#         active_mask,
#         op_start,
#         op_end,
#         op_proc,
#         op_machine,
#         machine_pred,
#         machine_succ,
#     ) = result
#
#     if not return_details:
#         return makespan, twt, tec
#
#     completion_times = completion_times_np.tolist()
#     job_weighted_tardiness = job_weighted_tardiness_np.tolist()
#
#     active_op_ids = np.flatnonzero(active_mask)
#     operation_info = {}
#     successors = {}
#
#     for oid in active_op_ids:
#         factory, lap, job, stage = _decode_op_id(
#             int(oid), info["num_laps"], info["num_jobs"], info["num_stages"]
#         )
#
#         mp_id = int(machine_pred[oid])
#         ms_id = int(machine_succ[oid])
#
#         machine_predecessor = (
#             _decode_op_id(mp_id, info["num_laps"], info["num_jobs"], info["num_stages"])
#             if mp_id != -1 else None
#         )
#         machine_successor = (
#             _decode_op_id(ms_id, info["num_laps"], info["num_jobs"], info["num_stages"])
#             if ms_id != -1 else None
#         )
#
#         if stage > 0:
#             job_predecessor = (factory, lap, job, stage - 1)
#         elif lap > 0:
#             job_predecessor = (factory, lap - 1, job, info["num_stages"] - 1)
#         else:
#             job_predecessor = None
#
#         if stage < info["num_stages"] - 1:
#             job_successor = (factory, lap, job, stage + 1)
#         elif lap < info["num_laps"] - 1:
#             job_successor = (factory, lap + 1, job, 0)
#         else:
#             job_successor = None
#
#         op = (factory, lap, job, stage)
#         operation_info[op] = {
#             "factory": factory,
#             "lap": lap,
#             "job": job,
#             "stage": stage,
#             "machine": int(op_machine[oid]),
#             "proc_time": float(op_proc[oid]),
#             "start": float(op_start[oid]),
#             "end": float(op_end[oid]),
#             "job_predecessor": job_predecessor,
#             "job_successor": job_successor,
#             "machine_predecessor": machine_predecessor,
#             "machine_successor": machine_successor,
#         }
#         successors[op] = []
#
#     for op, op_info in operation_info.items():
#         if op_info["machine_successor"] is not None:
#             successors[op].append(op_info["machine_successor"])
#         if op_info["job_successor"] is not None:
#             successors[op].append(op_info["job_successor"])
#
#     latest_finish = {}
#     latest_start = {}
#     sorted_ops_desc = sorted(operation_info.keys(), key=lambda x: operation_info[x]["end"], reverse=True)
#
#     eps_cp = 1e-9
#     for op in sorted_ops_desc:
#         succs = successors[op]
#         p_time = operation_info[op]["proc_time"]
#         lf = min(latest_start[s] for s in succs) if succs else makespan
#         latest_finish[op] = lf
#         latest_start[op] = lf - p_time
#
#     operation_slacks = {}
#     critical_operations = set()
#     for op, op_info in operation_info.items():
#         slack = latest_start[op] - op_info["start"]
#         operation_slacks[op] = slack
#         if abs(slack) <= eps_cp:
#             critical_operations.add(op)
#
#     return makespan, twt, tec, {
#         "completion_times": completion_times,
#         "job_weighted_tardiness": job_weighted_tardiness,
#         "scheduled_jobs": scheduled_jobs.tolist(),
#         "operation_info": operation_info,
#         "operation_slacks": operation_slacks,
#         "critical_operations": critical_operations,
#         "latest_start": latest_start,
#         "latest_finish": latest_finish,
#         "successors": successors,
#     }
def decode_with_critical_path(
    problem,
    job_sequence,
    factory_assignment,
    speed_vector,
    return_details=False,
):
    if njit is None:
        raise ImportError(
            "decode_with_critical_path needs numba: pip install numba"
        )

    info = _problem_info(problem)
    num_jobs = info["num_jobs"]

    scheduled_jobs = np.asarray(job_sequence, dtype=np.int64)

    if scheduled_jobs.size == 0:
        if return_details:
            return 0.0, 0.0, 0.0, {
                "completion_times": [0.0 for _ in range(num_jobs)],
                "job_weighted_tardiness": [0.0 for _ in range(num_jobs)],
                "scheduled_jobs": [],
                "critical_operations": set(),
                "operation_slacks": {},
                "operation_info": {},
                "latest_start": {},
                "latest_finish": {},
                "successors": {},
            }

        return 0.0, 0.0, 0.0

    result, scheduled_jobs = _run_decode_with_cp_core(
        problem,
        job_sequence,
        factory_assignment,
        speed_vector,
    )

    (
        makespan,
        twt,
        tec,
        completion_times_np,
        job_weighted_tardiness_np,
        active_mask,
        op_start,
        op_end,
        op_proc,
        op_machine,
        machine_pred,
        machine_succ,
    ) = result

    if not return_details:
        return makespan, twt, tec

    completion_times = completion_times_np.tolist()
    job_weighted_tardiness = job_weighted_tardiness_np.tolist()

    active_op_ids = np.flatnonzero(active_mask)

    operation_info = {}
    successors = {}

    # 建立操作信息
    for oid in active_op_ids:
        oid = int(oid)

        factory, lap, job, stage = _decode_op_id(
            oid,
            info["num_laps"],
            info["num_jobs"],
            info["num_stages"],
        )

        machine_predecessor_id = int(machine_pred[oid])
        machine_successor_id = int(machine_succ[oid])

        machine_predecessor = (
            _decode_op_id(
                machine_predecessor_id,
                info["num_laps"],
                info["num_jobs"],
                info["num_stages"],
            )
            if machine_predecessor_id != -1
            else None
        )

        machine_successor = (
            _decode_op_id(
                machine_successor_id,
                info["num_laps"],
                info["num_jobs"],
                info["num_stages"],
            )
            if machine_successor_id != -1
            else None
        )

        if stage > 0:
            job_predecessor = (
                factory,
                lap,
                job,
                stage - 1,
            )
        elif lap > 0:
            job_predecessor = (
                factory,
                lap - 1,
                job,
                info["num_stages"] - 1,
            )
        else:
            job_predecessor = None

        if stage < info["num_stages"] - 1:
            job_successor = (
                factory,
                lap,
                job,
                stage + 1,
            )
        elif lap < info["num_laps"] - 1:
            job_successor = (
                factory,
                lap + 1,
                job,
                0,
            )
        else:
            job_successor = None

        op = (factory, lap, job, stage)

        operation_info[op] = {
            "factory": factory,
            "lap": lap,
            "job": job,
            "stage": stage,
            "machine": int(op_machine[oid]),
            "proc_time": float(op_proc[oid]),
            "start": float(op_start[oid]),
            "end": float(op_end[oid]),
            "job_predecessor": job_predecessor,
            "job_successor": job_successor,
            "machine_predecessor": machine_predecessor,
            "machine_successor": machine_successor,
        }

        successors[op] = []

    # 建立后继关系
    for op, op_info in operation_info.items():
        if op_info["machine_successor"] is not None:
            successors[op].append(
                op_info["machine_successor"]
            )

        if op_info["job_successor"] is not None:
            successors[op].append(
                op_info["job_successor"]
            )

    # 删除重复后继
    for op in successors:
        successors[op] = list(
            dict.fromkeys(successors[op])
        )

    operation_set = set(operation_info.keys())

    # 检查后继操作是否存在
    missing_successors = {
        successor
        for succs in successors.values()
        for successor in succs
        if successor not in operation_set
    }

    if missing_successors:
        raise ValueError(
            "Missing successor operations: "
            f"{sorted(missing_successors)[:10]}"
        )

    # 建立反向邻接表
    predecessors = {
        op: []
        for op in operation_set
    }

    remaining_successor_count = {}

    for op in operation_set:
        succs = successors[op]
        remaining_successor_count[op] = len(succs)

        for successor in succs:
            predecessors[successor].append(op)

    # 从末端操作开始反向拓扑计算
    queue = [
        op
        for op in operation_set
        if remaining_successor_count[op] == 0
    ]

    latest_start = {}
    latest_finish = {}

    queue_index = 0

    while queue_index < len(queue):
        op = queue[queue_index]
        queue_index += 1

        succs = successors[op]

        if succs:
            latest_finish[op] = min(
                latest_start[successor]
                for successor in succs
            )
        else:
            latest_finish[op] = float(makespan)

        latest_start[op] = (
            latest_finish[op]
            - operation_info[op]["proc_time"]
        )

        for predecessor in predecessors[op]:
            remaining_successor_count[predecessor] -= 1

            if remaining_successor_count[predecessor] == 0:
                queue.append(predecessor)

    # 检查是否存在环或非法依赖
    if len(latest_start) != len(operation_info):
        unresolved = [
            op
            for op in operation_info
            if op not in latest_start
        ]

        raise ValueError(
            "Operation graph contains a cycle or invalid "
            "precedence relations. Unresolved operations: "
            f"{unresolved[:10]}"
        )

    # 计算操作时差并识别关键操作
    operation_slacks = {}
    critical_operations = set()
    eps_cp = 1e-9

    for op, op_info in operation_info.items():
        slack = latest_start[op] - op_info["start"]
        operation_slacks[op] = slack

        if abs(slack) <= eps_cp:
            critical_operations.add(op)

    return makespan, twt, tec, {
        "completion_times": completion_times,
        "job_weighted_tardiness": job_weighted_tardiness,
        "scheduled_jobs": scheduled_jobs.tolist(),
        "operation_info": operation_info,
        "operation_slacks": operation_slacks,
        "critical_operations": critical_operations,
        "latest_start": latest_start,
        "latest_finish": latest_finish,
        "successors": successors,
    }

def _clear_analysis_cache(individual):
    individual._critical_mask_cache_key = None
    individual._critical_mask_cache = None
    individual._critical_path_cache_key = None
    individual._critical_path_cache = None
    return individual


def _get_cached_critical_mask(problem, individual):
    key = _solution_key(individual)
    cache_key = getattr(individual, "_critical_mask_cache_key", None)
    if cache_key == key:
        cached = getattr(individual, "_critical_mask_cache", None)
        if cached is not None:
            return cached

    details = decode_with_critical_mask(
        problem,
        individual.job_sequence,
        individual.factory_assignment,
        individual.speed_vector,
    )
    individual._critical_mask_cache_key = key
    individual._critical_mask_cache = details
    return details


def _get_cached_critical_path(problem, individual):
    key = _solution_key(individual)
    cache_key = getattr(individual, "_critical_path_cache_key", None)
    if cache_key == key:
        cached = getattr(individual, "_critical_path_cache", None)
        if cached is not None:
            return cached

    makespan, twt, tec, details = decode_with_critical_path(
        problem,
        individual.job_sequence,
        individual.factory_assignment,
        individual.speed_vector,
        return_details=True,
    )
    cached = {
        "makespan": float(makespan),
        "twt": float(twt),
        "tec": float(tec),
        "details": details,
    }
    individual._critical_path_cache_key = key
    individual._critical_path_cache = cached
    return cached


def dominates(a, b):
    a0, a1, a2 = a.makespan, a.TWT, a.TEC
    b0, b1, b2 = b.makespan, b.TWT, b.TEC
    return (a0 <= b0 and a1 <= b1 and a2 <= b2 and (a0 < b0 or a1 < b1 or a2 < b2))


def _spawn_child(individual):
    child = Solution(
        makespan=0.0,
        TWT=0.0,
        TEC=0.0,
        job_sequence=individual.job_sequence,
        factory_assignment=individual.factory_assignment,
        speed_vector=individual.speed_vector,
        completion_times=None,
        gantt_records=None,
    )
    child.cached_key = None
    _clear_analysis_cache(child)
    return child


def _copy_job_sequence(job_sequence):
    return job_sequence[:]


def _copy_factory_assignment(factory_assignment):
    return factory_assignment[:]


def _copy_speed_vector_single_edit(speed_vector, lap_idx, job_idx):
    new_speed_vector = speed_vector[:]
    new_lap = speed_vector[lap_idx][:]
    new_job_speeds = speed_vector[lap_idx][job_idx][:]
    new_lap[job_idx] = new_job_speeds
    new_speed_vector[lap_idx] = new_lap
    return new_speed_vector


def _sorted_speed_levels(problem):
    cache_key = problem
    ordered = _ORDERED_SPEED_LEVELS_CACHE.get(cache_key)
    if ordered is None:
        speed_levels = _problem_info(problem)["speed_levels"]
        ordered = tuple(sorted(speed_levels.keys(), key=lambda lv: speed_levels[lv]))
        _ORDERED_SPEED_LEVELS_CACHE[cache_key] = ordered
    return ordered


def _speed_index_map(problem):
    cache_key = problem
    mapping = _SPEED_INDEX_CACHE.get(cache_key)
    if mapping is None:
        ordered = _sorted_speed_levels(problem)
        mapping = {level: idx for idx, level in enumerate(ordered)}
        _SPEED_INDEX_CACHE[cache_key] = mapping
    return mapping


def _max_speed_level(problem):
    return _sorted_speed_levels(problem)[-1]


def _min_speed_level(problem):
    return _sorted_speed_levels(problem)[0]


def _factory_jobs_in_order(job_sequence, factory_assignment, factory_id):
    return [job for job in job_sequence if factory_assignment[job] == factory_id]


def _rebuild_global_sequence_by_factory_order(factory_orders, num_jobs):
    seq = []
    for jobs in factory_orders:
        seq.extend(jobs)
    return seq


def _find_max_twt_job(problem, individual):
    completion_times = getattr(individual, "completion_times", None)
    if completion_times is None:
        return None, 0.0

    info = _problem_info(problem)
    due_dates = info["due_dates"]
    penalty_factors = info["penalty_factors"]

    target_job = None
    max_wt = -1.0
    tie_count = 0
    eps = 1e-12

    for job in range(len(completion_times)):
        tardiness = completion_times[job] - due_dates[job]
        wt = 0.0 if tardiness <= 0.0 else tardiness * penalty_factors[job]

        if wt > max_wt + eps:
            max_wt = wt
            target_job = job
            tie_count = 1
        elif abs(wt - max_wt) <= eps:
            tie_count += 1
            if random.randrange(tie_count) == 0:
                target_job = job

    return target_job, max_wt


def _task_speed_levels(problem, task_name):
    cache_key = (problem, task_name)
    ordered = _TASK_SPEED_LEVELS_CACHE.get(cache_key)
    if ordered is None:
        groups = _split_task_speed_levels(problem)
        ordered = tuple(groups[task_name])
        _TASK_SPEED_LEVELS_CACHE[cache_key] = ordered
    return ordered


def _task_speed_index_map(problem, task_name):
    cache_key = (problem, task_name)
    mapping = _TASK_SPEED_INDEX_CACHE.get(cache_key)
    if mapping is None:
        ordered = _task_speed_levels(problem, task_name)
        mapping = {level: idx for idx, level in enumerate(ordered)}
        _TASK_SPEED_INDEX_CACHE[cache_key] = mapping
    return mapping


def _task_speed_bounds(problem, task_name):
    cache_key = (problem, task_name)
    bounds = _TASK_SPEED_BOUNDS_CACHE.get(cache_key)
    if bounds is None:
        ordered = _task_speed_levels(problem, task_name)
        bounds = (ordered[0], ordered[-1])
        _TASK_SPEED_BOUNDS_CACHE[cache_key] = bounds
    return bounds


def _task_min_speed_level(problem, task_name):
    return _task_speed_bounds(problem, task_name)[0]


def _task_max_speed_level(problem, task_name):
    return _task_speed_bounds(problem, task_name)[1]


def _find_backward_speedup_position(problem, individual, target_job, task_name):
    info = _problem_info(problem)
    num_laps = info["num_laps"]
    num_stages = info["num_stages"]
    min_level = _task_min_speed_level(problem, task_name)
    max_level = _task_max_speed_level(problem, task_name)

    lap = num_laps - 1
    stage = num_stages - 1
    speed = _safe_speed_level(individual.speed_vector, lap, target_job, stage)
    if speed is not None and min_level <= speed < max_level:
        return lap, target_job, stage

    for lap in range(min(num_laps, len(individual.speed_vector)) - 1, -1, -1):
        lap_data = individual.speed_vector[lap]
        if target_job >= len(lap_data):
            continue
        job_data = lap_data[target_job]
        upper_stage = min(num_stages, len(job_data))
        for stage in range(upper_stage - 1, -1, -1):
            speed = job_data[stage]
            if min_level <= speed < max_level:
                return lap, target_job, stage

    for lap in range(min(num_laps, len(individual.speed_vector)) - 1, -1, -1):
        lap_data = individual.speed_vector[lap]
        for job in range(len(lap_data) - 1, -1, -1):
            job_data = lap_data[job]
            upper_stage = min(num_stages, len(job_data))
            for stage in range(upper_stage - 1, -1, -1):
                speed = job_data[stage]
                if min_level <= speed < max_level:
                    return lap, job, stage

    return None


def _speed_up_one_level(problem, speed_vector, lap, job, stage, task_name):
    ordered = _task_speed_levels(problem, task_name)
    index_map = _task_speed_index_map(problem, task_name)

    cur = _safe_speed_level(speed_vector, lap, job, stage)
    idx = index_map.get(cur)
    if idx is None:
        return False
    next_idx = idx + 1
    if next_idx >= len(ordered):
        return False
    speed_vector[lap][job][stage] = ordered[next_idx]
    return True


def _slow_down_one_level(problem, speed_vector, lap, job, stage, task_name):
    ordered = _task_speed_levels(problem, task_name)
    index_map = _task_speed_index_map(problem, task_name)

    cur = _safe_speed_level(speed_vector, lap, job, stage)
    idx = index_map.get(cur)
    if idx is None or idx == 0:
        return False

    speed_vector[lap][job][stage] = ordered[idx - 1]
    return True


def _random_job_operation_for_speedup(problem, speed_vector, target_job, task_name):
    min_level, max_level = _task_speed_bounds(problem, task_name)
    chosen = None
    count = 0

    for lap_idx, lap_data in enumerate(speed_vector):
        if target_job >= len(lap_data):
            continue

        job_speeds = lap_data[target_job]
        for stage_idx, speed in enumerate(job_speeds):
            if min_level <= speed < max_level:
                count += 1
                if random.randrange(count) == 0:
                    chosen = (lap_idx, target_job, stage_idx)

    return chosen


def tag_population_task_type(population, task_name):
    for ind in population:
        ind.task_type = task_name
    return population


def _wrap_task_operator(operator, task_name):
    def wrapped(problem, individual):
        child = operator(problem, individual, task_name=task_name)
        if child is not None:
            child.task_type = task_name
        return child

    wrapped.__name__ = f"{task_name}_{operator.__name__}"
    return wrapped


def ls_critical_twt_job_swap(problem, individual, task_name):
    info = _problem_info(problem)
    due_dates = info["due_dates"]
    penalty_factors = info["penalty_factors"]
    seq = individual.job_sequence
    n = len(seq)

    target_job, max_wt = _find_max_twt_job(problem, individual)

    # 若当前解没有拖期，则退化为随机交换两个工件，避免空操作
    if target_job is None or max_wt <= 0.0:
        i1, i2 = random.sample(range(n), 2)
        child = _spawn_child(individual)
        child.job_sequence = _copy_job_sequence(seq)
        child.job_sequence[i1], child.job_sequence[i2] = child.job_sequence[i2], child.job_sequence[i1]
        return _finalize_child(child)

    target_factory = individual.factory_assignment[target_job]

    # 一次性建立全局位置映射
    pos_map = {job: idx for idx, job in enumerate(seq)}
    target_pos = pos_map.get(target_job, -1)
    if target_pos <= 0:
        # target 不在序列中，或已经在最前面，则退化为随机交换
        i1, i2 = random.sample(range(n), 2)
        child = _spawn_child(individual)
        child.job_sequence = _copy_job_sequence(seq)
        child.job_sequence[i1], child.job_sequence[i2] = child.job_sequence[i2], child.job_sequence[i1]
        return _finalize_child(child)

    # 只收集目标工件之前、且同工厂的工件
    front_jobs = []
    fa = individual.factory_assignment
    for idx in range(target_pos):
        job = seq[idx]
        if fa[job] == target_factory:
            front_jobs.append(job)

    candidate = None
    target_due = due_dates[target_job]
    target_penalty = penalty_factors[target_job]

    # 单次反向扫描，优先级保持不变
    fallback_same_due = None
    for job in reversed(front_jobs):
        pj = penalty_factors[job]
        dj = due_dates[job]

        if pj == target_penalty and dj > target_due:
            candidate = job
            break

        if fallback_same_due is None and dj == target_due and pj > target_penalty:
            fallback_same_due = job

    if candidate is None:
        candidate = fallback_same_due

    if candidate is None and front_jobs:
        candidate = random.choice(front_jobs)

    if candidate is None:
        # 前面没有同工厂工件时，也退化为随机交换，避免浪费一次局部搜索
        i1, i2 = random.sample(range(n), 2)
        child = _spawn_child(individual)
        child.job_sequence = _copy_job_sequence(seq)
        child.job_sequence[i1], child.job_sequence[i2] = child.job_sequence[i2], child.job_sequence[i1]
        return _finalize_child(child)

    i1 = target_pos
    i2 = pos_map[candidate]

    child = _spawn_child(individual)
    child.job_sequence = _copy_job_sequence(seq)
    child.job_sequence[i1], child.job_sequence[i2] = child.job_sequence[i2], child.job_sequence[i1]
    return _finalize_child(child)


def ls_critical_twt_job_speed(problem, individual, task_name, eps=1e-9):
    completion_times = getattr(individual, "completion_times", None)
    if completion_times is None:
        return None

    info = _problem_info(problem)
    due_dates = info["due_dates"]
    penalty_factors = info["penalty_factors"]

    best_penalty = -1.0
    target_job = None
    tie_count = 0

    for job in range(len(completion_times)):
        if completion_times[job] <= due_dates[job] + eps:
            continue

        penalty = penalty_factors[job]
        if penalty > best_penalty + eps:
            best_penalty = penalty
            target_job = job
            tie_count = 1
        elif abs(penalty - best_penalty) <= eps:
            tie_count += 1
            if random.randrange(tie_count) == 0:
                target_job = job

    if target_job is None:
        return None

    chosen = _random_job_operation_for_speedup(problem, individual.speed_vector, target_job, task_name)
    if chosen is None:
        return None

    child = _spawn_child(individual)
    lap, job, stage = chosen
    child.speed_vector = _copy_speed_vector_single_edit(individual.speed_vector, lap, job)
    if not _speed_up_one_level(problem, child.speed_vector, lap, job, stage, task_name):
        return None
    return _finalize_child(child)


def ls_critical_operations_speed(problem, individual, task_name):
    details = _get_cached_critical_mask(problem, individual)
    critical_operations = details["critical_ops"]
    if not critical_operations:
        return None

    min_level, max_level = _task_speed_bounds(problem, task_name)
    speed_vector = individual.speed_vector

    chosen = None
    count = 0
    for _, lap, job, stage in critical_operations:
        speed = _safe_speed_level(speed_vector, lap, job, stage)
        if speed is None or not (min_level <= speed < max_level):
            continue

        count += 1
        if random.randrange(count) == 0:
            chosen = (lap, job, stage)

    if chosen is None:
        return None

    lap, job, stage = chosen
    child = _spawn_child(individual)
    child.speed_vector = _copy_speed_vector_single_edit(speed_vector, lap, job)
    # 这里理论上一定能成功，保留判断只是保险
    if not _speed_up_one_level(problem, child.speed_vector, lap, job, stage, task_name):
        return None

    return _finalize_child(child)


def ls_noncritical_operations_slowdown(problem, individual, task_name):
    details = _get_cached_critical_mask(problem, individual)
    noncritical_operations = details["noncritical_ops"]
    if not noncritical_operations:
        return None

    min_level, max_level = _task_speed_bounds(problem, task_name)
    speed_vector = individual.speed_vector

    chosen = None
    count = 0
    for _, lap, job, stage in noncritical_operations:
        speed = _safe_speed_level(speed_vector, lap, job, stage)
        if speed is None or not (min_level < speed <= max_level):
            continue

        count += 1
        if random.randrange(count) == 0:
            chosen = (lap, job, stage)

    if chosen is None:
        return None

    lap, job, stage = chosen
    child = _spawn_child(individual)
    child.speed_vector = _copy_speed_vector_single_edit(speed_vector, lap, job)

    if not _slow_down_one_level(problem, child.speed_vector, lap, job, stage, task_name):
        return None

    return _finalize_child(child)


def ls_critical_factory_job_reassign(problem, individual, task_name):
    eps = 1e-9
    completion_times = getattr(individual, "completion_times", None)
    if completion_times is None or problem.num_factorys <= 1:
        return None

    num_factories = problem.num_factorys
    num_jobs = problem.num_jobs
    seq = individual.job_sequence
    fa = individual.factory_assignment

    # 1. 选一个最大完工时间工件
    max_completion = max(completion_times)
    target_job = None
    tie_count = 0
    for job in range(num_jobs):
        if abs(completion_times[job] - max_completion) <= eps:
            tie_count += 1
            if random.randrange(tie_count) == 0:
                target_job = job

    if target_job is None:
        return None

    source_factory = fa[target_job]

    # 2. 估计每个工厂的“尾部完工时间”
    factory_completion = [0.0] * num_factories
    for job in range(num_jobs):
        f = fa[job]
        c = completion_times[job]
        if c > factory_completion[f]:
            factory_completion[f] = c

    # 3. 选最轻工厂
    target_factory = None
    best_completion = None
    tie_count = 0
    for f in range(num_factories):
        if f == source_factory:
            continue
        c = factory_completion[f]
        if best_completion is None or c < best_completion - eps:
            best_completion = c
            target_factory = f
            tie_count = 1
        elif abs(c - best_completion) <= eps:
            tie_count += 1
            if random.randrange(tie_count) == 0:
                target_factory = f

    if target_factory is None:
        return None

    # 4. 轻量修改：直接在全局序列里删掉再插入
    child = _spawn_child(individual)
    child.factory_assignment = _copy_factory_assignment(fa)
    child.job_sequence = _copy_job_sequence(seq)

    child.factory_assignment[target_job] = target_factory

    old_pos = child.job_sequence.index(target_job)
    child.job_sequence.pop(old_pos)

    target_positions = [
        i for i, job in enumerate(child.job_sequence)
        if child.factory_assignment[job] == target_factory
    ]

    if target_positions:
        insert_pos = random.randint(target_positions[0], target_positions[-1] + 1)
    else:
        insert_pos = len(child.job_sequence)

    child.job_sequence.insert(insert_pos, target_job)
    return _finalize_child(child)


def ls_random_insert(problem, individual, task_name):
    seq = individual.job_sequence
    if len(seq) < 2:
        return None

    child = _spawn_child(individual)
    child.job_sequence = _copy_job_sequence(seq)
    seq = child.job_sequence
    i, j = random.sample(range(len(seq)), 2)
    job = seq.pop(i)
    seq.insert(j, job)
    return _finalize_child(child)


def ls_random_job_factory_reassign(problem, individual, task_name):
    info = _problem_info(problem)
    num_factories = info["num_factories"]
    num_jobs = info["num_jobs"]
    if num_jobs == 0 or num_factories <= 1:
        return None

    target_job = random.randrange(num_jobs)
    source_factory = individual.factory_assignment[target_job]

    if num_factories == 2:
        target_factory = 1 - source_factory
    else:
        target_factory = random.randrange(num_factories - 1)
        if target_factory >= source_factory:
            target_factory += 1

    child = _spawn_child(individual)
    child.factory_assignment = _copy_factory_assignment(individual.factory_assignment)
    child.factory_assignment[target_job] = target_factory
    return _finalize_child(child)


def ls_critical_factory_last_operation_speedup(problem, individual, task_name):
    eps = 1e-9
    completion_times = getattr(individual, "completion_times", None)
    if completion_times is None:
        return None

    max_completion = max(completion_times)
    target_job = None
    tie_count = 0
    for job, completion in enumerate(completion_times):
        if abs(completion - max_completion) <= eps:
            tie_count += 1
            if random.randrange(tie_count) == 0:
                target_job = job

    if target_job is None:
        return None

    chosen = _find_backward_speedup_position(problem, individual, target_job, task_name)
    if chosen is None:
        return None

    lap, job, stage = chosen
    child = _spawn_child(individual)
    child.speed_vector = _copy_speed_vector_single_edit(individual.speed_vector, lap, job)
    if not _speed_up_one_level(problem, child.speed_vector, lap, job, stage, task_name):
        return None
    return _finalize_child(child)

def ls_random_swap(problem, individual, task_name):
    seq = individual.job_sequence
    if len(seq) < 2:
        return None

    child = _spawn_child(individual)
    child.job_sequence = _copy_job_sequence(seq)

    i, j = random.sample(range(len(seq)), 2)
    child.job_sequence[i], child.job_sequence[j] = child.job_sequence[j], child.job_sequence[i]
    return _finalize_child(child)


def ls_random_operation_speedup(problem, individual, task_name):
    chosen = _random_feasible_speed_position(
        problem,
        individual.speed_vector,
        task_name,
        for_speedup=True,
    )
    if chosen is None:
        return None

    lap, job, stage = chosen
    child = _spawn_child(individual)
    child.speed_vector = _copy_speed_vector_single_edit(individual.speed_vector, lap, job)

    if not _speed_up_one_level(problem, child.speed_vector, lap, job, stage, task_name):
        return None
    return _finalize_child(child)


def ls_random_operation_slowdown(problem, individual, task_name):
    chosen = _random_feasible_speed_position(
        problem,
        individual.speed_vector,
        task_name,
        for_speedup=False,
    )
    if chosen is None:
        return None

    lap, job, stage = chosen
    child = _spawn_child(individual)
    child.speed_vector = _copy_speed_vector_single_edit(individual.speed_vector, lap, job)

    if not _slow_down_one_level(problem, child.speed_vector, lap, job, stage, task_name):
        return None
    return _finalize_child(child)

LOW_SPEED_OPERATORS = (
    _wrap_task_operator(ls_critical_twt_job_swap, "low"),
    _wrap_task_operator(ls_critical_operations_speed, "low"),
    _wrap_task_operator(ls_noncritical_operations_slowdown, "low"),
    _wrap_task_operator(ls_critical_twt_job_speed, "low"),
    _wrap_task_operator(ls_critical_factory_job_reassign, "low"),
    _wrap_task_operator(ls_critical_factory_last_operation_speedup, "low"),
    _wrap_task_operator(ls_random_insert, "low"),
    _wrap_task_operator(ls_random_job_factory_reassign, "low"),
    _wrap_task_operator(ls_random_swap, "low"),
    _wrap_task_operator(ls_random_operation_speedup, "low"),
    _wrap_task_operator(ls_random_operation_slowdown, "low"),
)

MIDDLE_SPEED_OPERATORS = (
    _wrap_task_operator(ls_critical_twt_job_swap, "middle"),
    _wrap_task_operator(ls_critical_operations_speed, "middle"),
    _wrap_task_operator(ls_noncritical_operations_slowdown, "middle"),
    _wrap_task_operator(ls_critical_twt_job_speed, "middle"),
    _wrap_task_operator(ls_critical_factory_job_reassign, "middle"),
    _wrap_task_operator(ls_critical_factory_last_operation_speedup, "middle"),
    _wrap_task_operator(ls_random_insert, "middle"),
    _wrap_task_operator(ls_random_job_factory_reassign, "middle"),
    _wrap_task_operator(ls_random_swap, "middle"),
    _wrap_task_operator(ls_random_operation_speedup, "middle"),
    _wrap_task_operator(ls_random_operation_slowdown, "middle"),
)

HIGH_SPEED_OPERATORS = (
    _wrap_task_operator(ls_critical_twt_job_swap, "high"),
    _wrap_task_operator(ls_critical_operations_speed, "high"),
    _wrap_task_operator(ls_noncritical_operations_slowdown, "high"),
    _wrap_task_operator(ls_critical_twt_job_speed, "high"),
    _wrap_task_operator(ls_critical_factory_job_reassign, "high"),
    _wrap_task_operator(ls_critical_factory_last_operation_speedup, "high"),
    _wrap_task_operator(ls_random_insert, "high"),
    _wrap_task_operator(ls_random_job_factory_reassign, "high"),
    # _wrap_task_operator(ls_random_swap, "high"),
    # _wrap_task_operator(ls_random_operation_speedup, "high"),
    # _wrap_task_operator(ls_random_operation_slowdown, "high"),
)

MAIN_OPERATORS = (
    _wrap_task_operator(ls_critical_twt_job_swap, "main"),
    _wrap_task_operator(ls_critical_operations_speed, "main"),
    _wrap_task_operator(ls_noncritical_operations_slowdown, "main"),
    _wrap_task_operator(ls_critical_twt_job_speed, "main"),
    _wrap_task_operator(ls_critical_factory_job_reassign, "main"),
    _wrap_task_operator(ls_critical_factory_last_operation_speedup, "main"),
    _wrap_task_operator(ls_random_insert, "main"),
    _wrap_task_operator(ls_random_job_factory_reassign, "main"),
    _wrap_task_operator(ls_random_swap, "main"),
    _wrap_task_operator(ls_random_operation_speedup, "main"),
    _wrap_task_operator(ls_random_operation_slowdown, "main"),
)
