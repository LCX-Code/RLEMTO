import random
from copy import deepcopy

from Algorithm.Numba.RLEMTO.Solution import Solution
from Algorithm.Numba.RLEMTO.decode import decode, decode_batch


def _to_completion_list(completion_times):
    if completion_times is None:
        return None
    if hasattr(completion_times, "tolist"):
        return completion_times.tolist()
    return list(completion_times)


def _solution_key(job_sequence, factory_assignment, speed_vector):
    num_laps = len(speed_vector)
    num_jobs = len(speed_vector[0])
    num_stages = len(speed_vector[0][0])
    return (
        tuple(job_sequence),
        tuple(factory_assignment),
        tuple(
            speed_vector[l][j][s]
            for l in range(num_laps)
            for j in range(num_jobs)
            for s in range(num_stages)
        ),
    )


def _split_speed_groups(speed_candidates):
    q = len(speed_candidates)
    k, r = divmod(q, 3)

    if r == 0:
        low_size, middle_size, high_size = k, k, k
    elif r == 1:
        low_size, middle_size, high_size = k, k + 1, k
    else:
        low_size, middle_size, high_size = k + 1, k, k + 1

    low_end = low_size
    middle_end = low_end + middle_size

    speed_groups = {
        "low": speed_candidates[:low_end],
        "middle": speed_candidates[low_end:middle_end],
        "high": speed_candidates[middle_end:],
        "main": speed_candidates[:],
    }

    for mode in ("low", "middle", "high"):
        if not speed_groups[mode]:
            raise ValueError(
                f"Speed group '{mode}' is empty. Current speed levels: {speed_candidates}"
            )

    return speed_groups


def _decode_batch_with_optional_completion(problem, candidates):
    if not candidates:
        return [], [], [], None

    job_sequences = []
    seq_lengths = []
    factory_assignments = []
    speed_vectors = []

    for job_sequence, factory_assignment, speed_vector in candidates:
        job_sequences.append(job_sequence)
        seq_lengths.append(len(job_sequence))
        factory_assignments.append(factory_assignment)
        speed_vectors.append(speed_vector)

    batch_result = decode_batch(
        problem,
        job_sequences,
        seq_lengths,
        factory_assignments,
        speed_vectors,
    )

    if len(batch_result) == 4:
        makespans, twts, tecs, completion_times_batch = batch_result
    else:
        makespans, twts, tecs = batch_result
        completion_times_batch = None

    return makespans, twts, tecs, completion_times_batch


def _build_solutions_batch(problem, candidates):
    if not candidates:
        return []

    makespans, twts, tecs, completion_times_batch = _decode_batch_with_optional_completion(
        problem, candidates
    )

    solutions = []
    for i, (job_sequence, factory_assignment, speed_vector) in enumerate(candidates):
        if completion_times_batch is None:
            _, _, _, completion_times = decode(
                problem=problem,
                job_sequence=job_sequence,
                factory_assignment=factory_assignment,
                speed_vector=speed_vector,
                return_details=True,
            )
        else:
            completion_times = completion_times_batch[i]

        solutions.append(
            Solution(
                makespan=float(makespans[i]),
                TWT=float(twts[i]),
                TEC=float(tecs[i]),
                job_sequence=deepcopy(job_sequence),
                factory_assignment=deepcopy(factory_assignment),
                speed_vector=deepcopy(speed_vector),
                completion_times=_to_completion_list(completion_times),
            )
        )

    return solutions


def random_initialization(problem, popsize):
    num_factories = problem.num_factorys
    num_jobs = problem.num_jobs
    num_stages = problem.num_stages
    num_laps = problem.num_reentrances
    speed_candidates = sorted(problem.speed_levels.keys())

    candidates = []
    for _ in range(popsize):
        job_sequence = random.sample(range(num_jobs), num_jobs)
        factory_assignment = [random.randrange(num_factories) for _ in range(num_jobs)]
        speed_vector = [
            [
                [random.choice(speed_candidates) for _ in range(num_stages)]
                for _ in range(num_jobs)
            ]
            for _ in range(num_laps)
        ]
        candidates.append((job_sequence, factory_assignment, speed_vector))

    return _build_solutions_batch(problem, candidates)


def initialization(problem, Config):
    low_speed_task_size = Config.low_speed_task_size
    middle_speed_task_size = Config.middle_speed_task_size
    high_speed_task_size = Config.high_speed_task_size
    main_task_size = Config.main_speed_task_size

    num_jobs = problem.num_jobs
    num_factories = problem.num_factorys
    num_stages = problem.num_stages
    num_laps = problem.num_reentrances
    speed_candidates = sorted(problem.speed_levels.keys())

    due_dates = problem.due_dates
    penalty_factors = problem.penalty_factors
    factory_objectives = ["makespan", "TWT", "TEC"]
    speed_groups = _split_speed_groups(speed_candidates)

    def build_speed_vector(mode):
        candidates = speed_groups[mode]
        return [
            [[random.choice(candidates) for _ in range(num_stages)] for _ in range(num_jobs)]
            for _ in range(num_laps)
        ]

    def get_speed_ratio(speed_code):
        speed_value = problem.speed_levels[speed_code]
        if isinstance(speed_value, (list, tuple)):
            return float(speed_value[0])
        return float(speed_value)

    def compute_total_proc_by_speed(speed_vector):
        total_proc = []
        for j in range(num_jobs):
            total_time = 0.0
            for s in range(num_stages):
                for l in range(num_laps):
                    base_time = problem.processing_times[j][s][l]
                    speed_code = speed_vector[l][j][s]
                    speed_ratio = get_speed_ratio(speed_code)
                    total_time += base_time / max(speed_ratio, 1e-12)
            total_proc.append(total_time)
        return total_proc

    def build_rules(total_proc):
        def rule_spt():
            return sorted(range(num_jobs), key=lambda j: total_proc[j])

        def rule_lpt():
            return sorted(range(num_jobs), key=lambda j: total_proc[j], reverse=True)

        def rule_edd():
            return sorted(range(num_jobs), key=lambda j: due_dates[j])

        def rule_wur():
            def priority(j):
                slack = due_dates[j] - total_proc[j]
                weight = max(penalty_factors[j], 1e-12)
                if slack < 0:
                    return -((-slack) * weight)
                return slack / weight

            return sorted(range(num_jobs), key=priority)

        return [
            ("SPT", rule_spt),
            ("LPT", rule_lpt),
            ("EDD", rule_edd),
            ("DPP", rule_wur),
        ]

    def evaluate_partial_assignments_batch(job_sequences, factory_assignments, speed_vector, objective_name):
        candidates = [
            (job_sequences[i], factory_assignments[i], speed_vector)
            for i in range(len(job_sequences))
        ]
        makespans, twts, tecs, _ = _decode_batch_with_optional_completion(problem, candidates)

        if objective_name == "makespan":
            return makespans
        if objective_name == "TWT":
            return twts
        return tecs

    def assign_factories_by_objective(job_sequence, speed_vector, objective_name):
        factory_sequences = [[] for _ in range(num_factories)]

        for job in job_sequence:
            candidate_meta = []
            candidate_job_sequences = []
            candidate_factory_assignments = []

            for f in range(num_factories):
                current_seq = factory_sequences[f]

                for pos in range(len(current_seq) + 1):
                    trial_factory_sequences = [seq[:] for seq in factory_sequences]
                    trial_factory_sequences[f].insert(pos, job)

                    trial_job_sequence = []
                    trial_factory_assignment = [0] * num_jobs

                    for factory_id, seq in enumerate(trial_factory_sequences):
                        for j in seq:
                            trial_job_sequence.append(j)
                            trial_factory_assignment[j] = factory_id

                    candidate_meta.append((f, pos))
                    candidate_job_sequences.append(trial_job_sequence)
                    candidate_factory_assignments.append(trial_factory_assignment)

            values = evaluate_partial_assignments_batch(
                candidate_job_sequences,
                candidate_factory_assignments,
                speed_vector,
                objective_name,
            )

            best_idx = min(range(len(values)), key=lambda i: float(values[i]))
            best_factory, best_pos = candidate_meta[best_idx]
            factory_sequences[best_factory].insert(best_pos, job)

        final_job_sequence = []
        final_factory_assignment = [0] * num_jobs

        for factory_id, seq in enumerate(factory_sequences):
            for j in seq:
                final_job_sequence.append(j)
                final_factory_assignment[j] = factory_id

        return final_job_sequence, final_factory_assignment

    def build_population_for_speed_mode(speed_mode, task_size):
        population = []
        seen = set()
        pending_candidates = []

        def flush_pending():
            nonlocal population, pending_candidates
            if not pending_candidates:
                return
            new_solutions = _build_solutions_batch(problem, pending_candidates)
            population.extend(new_solutions)
            pending_candidates = []

        def add_candidate(job_sequence, factory_assignment, speed_vector):
            key = _solution_key(job_sequence, factory_assignment, speed_vector)
            if key in seen:
                return

            seen.add(key)
            pending_candidates.append((job_sequence, factory_assignment, speed_vector))

            if len(pending_candidates) >= 32:
                flush_pending()

        for objective_name in factory_objectives:
            for _ in range(4):
                speed_vector = build_speed_vector(speed_mode)
                total_proc = compute_total_proc_by_speed(speed_vector)
                rules = build_rules(total_proc)

                for _, rule_fn in rules:
                    job_sequence = rule_fn()
                    job_sequence, factory_assignment = assign_factories_by_objective(
                        job_sequence,
                        speed_vector,
                        objective_name,
                    )
                    add_candidate(job_sequence, factory_assignment, speed_vector)

                    if len(population) + len(pending_candidates) >= task_size:
                        flush_pending()
                        return population[:task_size]

        while len(population) + len(pending_candidates) < task_size:
            speed_vector = build_speed_vector(speed_mode)
            job_sequence = random.sample(range(num_jobs), num_jobs)
            factory_assignment = [random.randrange(num_factories) for _ in range(num_jobs)]
            add_candidate(job_sequence, factory_assignment, speed_vector)

        flush_pending()
        return population[:task_size]

    low_speed_task = build_population_for_speed_mode("low", low_speed_task_size)
    middle_speed_task = build_population_for_speed_mode("middle", middle_speed_task_size)
    high_speed_task = build_population_for_speed_mode("high", high_speed_task_size)
    main_task = build_population_for_speed_mode("main", main_task_size)

    return low_speed_task, middle_speed_task, high_speed_task, main_task
