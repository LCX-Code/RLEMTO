import os


class Config:
    crossover_prob = 0.8
    mutation_prob = 0.2

    low_speed_task_size = 25
    high_speed_task_size = 25
    middle_speed_task_size = 25
    main_speed_task_size = 50

    radius = 0.1
    g_time = None
    # random_seed = 42
    # Q-learning 参数
    q_epsilon_start = 1.0
    q_epsilon_min = 0.10
    q_alpha = 0.1
    q_gamma = 0.8

    @classmethod
    def update_from_problem(cls, problem, file_path):
        scale = os.path.basename(os.path.dirname(file_path))
        cls.g_time = 30 * problem.num_factorys * problem.num_stages * problem.num_reentrances * problem.num_jobs / 1000

    @classmethod
    def read_parameter(cls):
        return {
            k: v
            for k, v in cls.__dict__.items()
            if not k.startswith("_") and not callable(v)
        }
