import os
import time
from Algorithm.Numba.RLEMTO.knowledge_transfer import (
    init_transfer_q_learning,
    select_transfer_action_q,
    get_joint_min_max_from_points,
    update_transfer_q_learning,
    update_action_statistics,
    igd_reward,
    calculate_points_igd,
    igd_state,
    build_online_reference_front, apply_bidirectional_transfer,
)
from Algorithm.Numba.RLEMTO.adaptive_knowledge_enhanced import (
    update_operator_state_adaptive_pursuit,
    adaptive_init_operator_state, print_operator_state, task_adaptive_knowledge_local_search, task_adaptive_knowledge_local_search_nd,
)
from Algorithm.Numba.RLEMTO.speed_adjustment import knowledge_guided_speed_adjustment_operators
from Algorithm.Numba.RLEMTO.environmental_selection import  environmental_selection_by_task
from Algorithm.Numba.RLEMTO.genetic_operations import generate_offspring_by_task
from Algorithm.Numba.RLEMTO.initialization import initialization
from Algorithm.Numba.RLEMTO.local_search_operators import (
    LOW_SPEED_OPERATORS,
    MIDDLE_SPEED_OPERATORS,
    HIGH_SPEED_OPERATORS,
    MAIN_OPERATORS,
    tag_population_task_type,
)
from Algorithm.Painting.gantt import plot_gantt
from Algorithm.Painting.painting import plot_objective_space_four_tasks
from Algorithm.utils.non_dominated_sort import non_dominated_sort
from Algorithm.utils.read_instances import read_instances
from Algorithm.Numba.RLEMTO.config import Config


def RLEMTO_MA(file_path):
    problem = read_instances(file_path)
    Config.update_from_problem(problem, file_path)

    low_speed_task, middle_speed_task, high_speed_task, _ = initialization(problem, Config)

    tasks = {
        "low": low_speed_task,
        "middle": middle_speed_task,
        "high": high_speed_task,
        # "main": main_task,
    }

    operators_map = {
        "low": LOW_SPEED_OPERATORS,
        "middle": MIDDLE_SPEED_OPERATORS,
        "high": HIGH_SPEED_OPERATORS,
        # "main": MAIN_OPERATORS,
    }

    operator_states = {
        task_name: adaptive_init_operator_state(operators_map[task_name])
        for task_name in tasks
    }

    for task_name in tasks:
        tag_population_task_type(tasks[task_name], task_name)

    time_start = time.time()
    iter_count = 0

    while time.time() - time_start < Config.g_time:
        iter_count += 1

        records = {}
        elapsed = time.time() - time_start

        for task_name in tasks:
            #============================================ 遗传操作 =========================================
            tasks[task_name] = generate_offspring_by_task(problem, tasks[task_name], Config, task_name,)
            tag_population_task_type(tasks[task_name], task_name)
            #============================================ 环境选择 =========================================
            tasks[task_name] = environmental_selection_by_task(tasks[task_name], Config, elapsed, task_name,)
            #============================================ 知识增强 =========================================
            tasks[task_name], records[task_name] = task_adaptive_knowledge_local_search(problem, tasks[task_name], operator_states[task_name], operators_map[task_name], task_name,)
            #============================================ 环境选择 =========================================
            tasks[task_name] = environmental_selection_by_task(tasks[task_name], Config, elapsed, task_name,)
            #============================================ 更新状态 =========================================
            update_operator_state_adaptive_pursuit(operator_states[task_name], records[task_name], tasks[task_name], task_name,)

    print(iter_count)
    # for task_name in tasks:
    #     print_operator_state(f"{task_name}_operator_state", operator_states[task_name])

    population = []
    for task_name in tasks:
        population.extend(tasks[task_name])

    population = knowledge_guided_speed_adjustment_operators(problem, population)
    pareto_front = non_dominated_sort(population)[0]
    return pareto_front, iter_count


if __name__ == "__main__":
    folder_path = r"../../../../Experiment/instance/small"
    for root, dirs, files in os.walk(folder_path):
        for file in files:
            if file.startswith("") and file.endswith(".txt"):
                file_path = os.path.join(root, file)
                print(f"正在处理文件: {file_path}")
                RLEMTO_MA(file_path)
                print("-----------------------------------")
