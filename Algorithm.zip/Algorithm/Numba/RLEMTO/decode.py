import numpy as np

from numba import njit, prange



def _build_speed_lookup(speed_levels):
    max_level = max(speed_levels.keys())
    lookup = np.zeros(max_level + 1, dtype=np.float64)
    for level, speed in speed_levels.items():
        lookup[level] = speed
    return lookup


if njit is not None:
    @njit(cache=True)
    def _sort_jobs_by_values_inplace(jobs, values, length):
        for i in range(length - 1):
            min_pos = i
            min_job = jobs[i]
            min_val = values[min_job]
            for j in range(i + 1, length):
                job = jobs[j]
                val = values[job]
                if val < min_val:
                    min_val = val
                    min_job = job
                    min_pos = j
            if min_pos != i:
                jobs[i], jobs[min_pos] = jobs[min_pos], jobs[i]


    @njit(cache=True)
    def _decode_one_partial(
            job_sequence,
            seq_length,
            factory_assignment,
            speed_vector,
            num_factories,
            num_jobs,
            num_stages,
            num_laps,
            max_machines,
            num_machines_per_stage,
            processing_times,
            due_dates,
            penalty_factors,
            speed_lookup,
            unit_idle_power,
    ):
        c_times = np.zeros((num_factories, num_laps, num_jobs, num_stages), dtype=np.float64)
        machine_ready_times = np.zeros((num_factories, num_stages, max_machines), dtype=np.float64)
        machine_loads = np.zeros((num_factories, num_stages, max_machines), dtype=np.float64)
        machine_processing_energy = np.zeros((num_factories, num_stages, max_machines), dtype=np.float64)
        machine_idle_energy = np.zeros((num_factories, num_stages, max_machines), dtype=np.float64)

        first_lap_jobs_by_factory = np.full((num_factories, num_jobs), -1, dtype=np.int64)
        first_lap_counts = np.zeros(num_factories, dtype=np.int64)

        for idx in range(seq_length):
            job = job_sequence[idx]
            factory = factory_assignment[job]
            pos = first_lap_counts[factory]
            first_lap_jobs_by_factory[factory, pos] = job
            first_lap_counts[factory] += 1

        lap_sequence = np.empty(num_jobs, dtype=np.int64)
        stage_sequence = np.empty(num_jobs, dtype=np.int64)

        for factory in range(num_factories):
            length = first_lap_counts[factory]
            for i in range(length):
                lap_sequence[i] = first_lap_jobs_by_factory[factory, i]

            for lap in range(num_laps):
                if lap > 0:
                    prev_last_stage = c_times[factory, lap - 1, :, num_stages - 1]
                    _sort_jobs_by_values_inplace(lap_sequence, prev_last_stage, length)

                for i in range(length):
                    stage_sequence[i] = lap_sequence[i]

                for stage in range(num_stages):
                    if stage > 0:
                        prev_stage_ct = c_times[factory, lap, :, stage - 1]
                        _sort_jobs_by_values_inplace(stage_sequence, prev_stage_ct, length)

                    machine_count = num_machines_per_stage[stage]

                    for i in range(length):
                        job = stage_sequence[i]

                        if lap == 0 and stage == 0:
                            job_ready_time = 0.0
                        elif stage == 0:
                            job_ready_time = c_times[factory, lap - 1, job, num_stages - 1]
                        else:
                            job_ready_time = c_times[factory, lap, job, stage - 1]

                        speed_level = speed_vector[lap, job, stage]
                        speed = speed_lookup[speed_level]
                        p_time = processing_times[job, stage, lap] / speed
                        unit_processing_power = 4.0 * speed * speed

                        best_machine = 0
                        best_finish = 1e30
                        best_ready = 1e30
                        best_load = 1e30

                        for m in range(machine_count):
                            machine_ready = machine_ready_times[factory, stage, m]
                            start_time = machine_ready if machine_ready > job_ready_time else job_ready_time
                            finish_time = start_time + p_time
                            load = machine_loads[factory, stage, m]

                            if (
                                    finish_time < best_finish
                                    or (finish_time == best_finish and machine_ready < best_ready)
                                    or (finish_time == best_finish and machine_ready == best_ready and load < best_load)
                            ):
                                best_finish = finish_time
                                best_ready = machine_ready
                                best_load = load
                                best_machine = m

                        machine_ready = machine_ready_times[factory, stage, best_machine]
                        start_time = machine_ready if machine_ready > job_ready_time else job_ready_time
                        end_time = start_time + p_time
                        idle_time = start_time - machine_ready

                        machine_processing_energy[factory, stage, best_machine] += p_time * unit_processing_power
                        machine_idle_energy[factory, stage, best_machine] += idle_time * unit_idle_power

                        c_times[factory, lap, job, stage] = end_time
                        machine_ready_times[factory, stage, best_machine] = end_time
                        machine_loads[factory, stage, best_machine] += p_time

        last_lap = num_laps - 1
        last_stage = num_stages - 1

        makespan = 0.0
        twt = 0.0
        completion_times = np.zeros(num_jobs, dtype=np.float64)

        for idx in range(seq_length):
            job = job_sequence[idx]
            factory = factory_assignment[job]
            completion = c_times[factory, last_lap, job, last_stage]
            completion_times[job] = completion

            if completion > makespan:
                makespan = completion

            tardiness = completion - due_dates[job]
            if tardiness > 0.0:
                twt += tardiness * penalty_factors[job]

        tec = 0.0
        for factory in range(num_factories):
            for stage in range(num_stages):
                machine_count = num_machines_per_stage[stage]
                for m in range(machine_count):
                    tec += machine_processing_energy[factory, stage, m]
                    tec += machine_idle_energy[factory, stage, m]

        return makespan, twt, tec, completion_times


    @njit(parallel=True, cache=True)
    def _decode_batch_core(
            job_sequences,
            seq_lengths,
            factory_assignments,
            speed_vectors,
            num_factories,
            num_jobs,
            num_stages,
            num_laps,
            max_machines,
            num_machines_per_stage,
            processing_times,
            due_dates,
            penalty_factors,
            speed_lookup,
            unit_idle_power,
    ):
        popsize = job_sequences.shape[0]
        makespans = np.zeros(popsize, dtype=np.float64)
        twts = np.zeros(popsize, dtype=np.float64)
        tecs = np.zeros(popsize, dtype=np.float64)
        completion_times_batch = np.zeros((popsize, num_jobs), dtype=np.float64)

        for i in prange(popsize):
            makespan, twt, tec, completion_times = _decode_one_partial(
                job_sequences[i],
                seq_lengths[i],
                factory_assignments[i],
                speed_vectors[i],
                num_factories,
                num_jobs,
                num_stages,
                num_laps,
                max_machines,
                num_machines_per_stage,
                processing_times,
                due_dates,
                penalty_factors,
                speed_lookup,
                unit_idle_power,
            )
            makespans[i] = makespan
            twts[i] = twt
            tecs[i] = tec
            completion_times_batch[i, :] = completion_times

        return makespans, twts, tecs, completion_times_batch


    def decode(problem, job_sequence, factory_assignment, speed_vector, return_details=False):
        if njit is None:
            raise ImportError("decode 需要安装 numba: pip install numba")

        (
            num_speed_levels,
            num_factories,
            num_jobs,
            num_stages,
            num_laps,
            num_machines_per_stage,
            processing_times,
            due_dates,
            speed_levels,
            priorities,
            penalty_factors,
        ) = problem.info

        scheduled_jobs = np.asarray(job_sequence, dtype=np.int64)
        if scheduled_jobs.size == 0:
            if return_details:
                return 0.0, 0.0, 0.0, {
                    "completion_times": [0.0 for _ in range(num_jobs)],
                    "scheduled_jobs": [],
                }
            return 0.0, 0.0, 0.0

        factory_assignment = np.asarray(factory_assignment, dtype=np.int64)
        speed_vector = np.asarray(speed_vector, dtype=np.int64)
        num_machines_per_stage = np.asarray(num_machines_per_stage, dtype=np.int64)
        processing_times = np.asarray(processing_times, dtype=np.float64)
        due_dates = np.asarray(due_dates, dtype=np.float64)
        penalty_factors = np.asarray(penalty_factors, dtype=np.float64)
        speed_lookup = _build_speed_lookup(speed_levels)
        max_machines = int(num_machines_per_stage.max())

        makespan, twt, tec, completion_times = _decode_one_partial(
            scheduled_jobs,
            scheduled_jobs.size,
            factory_assignment,
            speed_vector,
            num_factories,
            num_jobs,
            num_stages,
            num_laps,
            max_machines,
            num_machines_per_stage,
            processing_times,
            due_dates,
            penalty_factors,
            speed_lookup,
            float(problem.unit_idle_power),
        )

        if return_details:
            return makespan, twt, tec, completion_times

        return makespan, twt, tec


    def decode_batch(problem, job_sequences, seq_lengths, factory_assignments, speed_vectors):
        if njit is None:
            raise ImportError("decode_batch 需要安装 numba: pip install numba")

        (
            num_speed_levels,
            num_factories,
            num_jobs,
            num_stages,
            num_laps,
            num_machines_per_stage,
            processing_times,
            due_dates,
            speed_levels,
            priorities,
            penalty_factors,
        ) = problem.info

        job_sequences = np.asarray(job_sequences, dtype=np.int64)
        seq_lengths = np.asarray(seq_lengths, dtype=np.int64)
        factory_assignments = np.asarray(factory_assignments, dtype=np.int64)
        speed_vectors = np.asarray(speed_vectors, dtype=np.int64)
        num_machines_per_stage = np.asarray(num_machines_per_stage, dtype=np.int64)
        processing_times = np.asarray(processing_times, dtype=np.float64)
        due_dates = np.asarray(due_dates, dtype=np.float64)
        penalty_factors = np.asarray(penalty_factors, dtype=np.float64)
        speed_lookup = _build_speed_lookup(speed_levels)
        max_machines = int(num_machines_per_stage.max())

        return _decode_batch_core(
            job_sequences,
            seq_lengths,
            factory_assignments,
            speed_vectors,
            num_factories,
            num_jobs,
            num_stages,
            num_laps,
            max_machines,
            num_machines_per_stage,
            processing_times,
            due_dates,
            penalty_factors,
            speed_lookup,
            float(problem.unit_idle_power),
        )