import random

import numpy as np
from pymoo.util.nds.non_dominated_sorting import NonDominatedSorting
from Algorithm.Numba.RLEMTO.local_search_operators import batch_decode_and_cache, _solution_key


def adaptive_init_operator_state(operators):
    k = len(operators)
    init_p = 1.0 / k if k > 0 else 0.0
    return {
        op.__name__: {
            "Q": 0.0,
            "P": init_p,
            "selected": 0,
            "generated": 0,
            "survived": 0,
            "last_selected": 0,
        }
        for op in operators
    }


def select_operator_adaptive_pursuit(operators, operator_state):
    r = random.random()
    cumulative = 0.0
    last_op = operators[-1]

    for op in operators:
        cumulative += operator_state[op.__name__]["P"]
        if r <= cumulative:
            operator_state[op.__name__]["selected"] += 1
            return op
        last_op = op

    operator_state[last_op.__name__]["selected"] += 1
    return last_op


def update_operator_state_adaptive_pursuit(operator_state, records, population, task_name=None):
    alpha = 0.8
    beta = 0.8

    selected_keys = {_solution_key(ind) for ind in population}
    generated_count = {name: 0 for name in operator_state}
    survived_count = {name: 0 for name in operator_state}

    for op_name, child_key in records:
        generated_count[op_name] += 1
        if child_key is not None and child_key in selected_keys:
            survived_count[op_name] += 1

    best_op_name = None
    best_q = -1.0

    for op_name, state in operator_state.items():
        s = survived_count[op_name]
        current_selected = state["selected"]
        sel = current_selected - state["last_selected"]

        state["generated"] += generated_count[op_name]
        state["survived"] += s
        state["last_selected"] = current_selected

        if sel > 0:
            reward = s / sel
            state["Q"] = state["Q"] + alpha * (reward - state["Q"])

        if state["Q"] > best_q:
            best_q = state["Q"]
            best_op_name = op_name

    if best_op_name is None:
        return

    k = len(operator_state)
    pmin = 1.0 / (2.0 * k)
    pmax = 1.0 - (k - 1) * pmin

    for op_name, state in operator_state.items():
        old_p = state["P"]
        if op_name == best_op_name:
            state["P"] = old_p + beta * (pmax - old_p)
        else:
            state["P"] = old_p + beta * (pmin - old_p)


def _run_task_knowledge_local_search(
    problem,
    population,
    operators,
    choose_operator_fn,
    operator_state=None,
    task_name=None,
):
    if not population:
        return population, []

    raw_offspring = []
    records = []
    seen = {_solution_key(ind) for ind in population}

    offspring_append = raw_offspring.append
    records_append = records.append
    seen_add = seen.add

    for parent in population:
        operator = choose_operator_fn(operators, operator_state)
        op_name = operator.__name__
        child = operator(problem, parent)

        if child is None:
            records_append((op_name, None))
            continue

        child_key = _solution_key(child)
        if child_key in seen:
            records_append((op_name, None))
            continue

        seen_add(child_key)
        offspring_append(child)
        records_append((op_name, child_key))

    if raw_offspring:
        batch_decode_and_cache(problem, raw_offspring)

    return population + raw_offspring, records


def _choose_operator_random(operators, operator_state=None):
    return random.choice(operators)


def task_adaptive_knowledge_local_search(problem, population, operator_state, operators, task_name=None):
    return _run_task_knowledge_local_search(
        problem,
        population,
        operators,
        choose_operator_fn=select_operator_adaptive_pursuit,
        operator_state=operator_state,
        task_name=task_name,
    )


def task_random_knowledge_local_search(problem, population, operators, task_name=None):
    return _run_task_knowledge_local_search(
        problem,
        population,
        operators,
        choose_operator_fn=_choose_operator_random,
        operator_state=None,
        task_name=task_name,
    )


def adaptive_knowledge_local_search_by_task(problem, population, operator_state, operators, task_name):
    return task_adaptive_knowledge_local_search(
        problem, population, operator_state, operators, task_name=task_name
    )


def random_knowledge_local_search_by_task(problem, population, operators, task_name):
    return task_random_knowledge_local_search(
        problem, population, operators, task_name=task_name
    )


def print_operator_state(title, operator_state):
    print(f"\n{title}")
    for op_name, state in operator_state.items():
        print(
            f"{op_name:<35} "
            f"Q={state['Q']:.4f}  "
            f"P={state['P']:.4f}  "
            f"selected={state['selected']}  "
            f"generated={state['generated']}  "
            f"survived={state['survived']}  "
            f"last_selected={state['last_selected']}"
        )


def _population_objectives(population):
    return np.asarray(
        [(float(ind.makespan), float(ind.TWT), float(ind.TEC)) for ind in population],
        dtype=float,
    )


def _extract_nondominated_population(population):
    if not population:
        return []

    points = _population_objectives(population)
    nd_indices = NonDominatedSorting().do(points, only_non_dominated_front=True)
    return [population[i] for i in nd_indices]


def _run_task_knowledge_local_search_on_nondominated(
    problem,
    population,
    operators,
    choose_operator_fn,
    operator_state=None,
    task_name=None,
):
    if not population:
        return population, []

    nd_population = _extract_nondominated_population(population)
    if not nd_population:
        return population, []

    raw_offspring = []
    records = []
    seen = {_solution_key(ind) for ind in population}

    offspring_append = raw_offspring.append
    records_append = records.append
    seen_add = seen.add

    for parent in nd_population:
        operator = choose_operator_fn(operators, operator_state)
        op_name = operator.__name__
        child = operator(problem, parent)

        if child is None:
            records_append((op_name, None))
            continue

        child_key = _solution_key(child)
        if child_key in seen:
            records_append((op_name, None))
            continue

        seen_add(child_key)
        offspring_append(child)
        records_append((op_name, child_key))

    if raw_offspring:
        batch_decode_and_cache(problem, raw_offspring)

    return population + raw_offspring, records

def task_adaptive_knowledge_local_search_nd(problem, population, operator_state, operators, task_name=None):
    return _run_task_knowledge_local_search_on_nondominated(
        problem,
        population,
        operators,
        choose_operator_fn=select_operator_adaptive_pursuit,
        operator_state=operator_state,
        task_name=task_name,
    )


def task_random_knowledge_local_search_nd(problem, population, operators, task_name=None):
    return _run_task_knowledge_local_search_on_nondominated(
        problem,
        population,
        operators,
        choose_operator_fn=_choose_operator_random,
        operator_state=None,
        task_name=task_name,
    )