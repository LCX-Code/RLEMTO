import copy
import random

import numpy as np
from Algorithm.Numba.RLEMTO.decode import decode_batch

try:
    from numba import njit
except ImportError:  # pragma: no cover
    njit = None


def _problem_info(problem):
    info = problem.info
    if len(info) == 11:
        (
            num_speed_levels,
            num_factories,
            num_jobs,
            num_stages,
            num_laps,
            num_machines_per_stage,
            processing_times,
            due_dates,
            speed_levels,
            priorities,
            penalty_factors,
        ) = info
    else:
        (
            num_factories,
            num_jobs,
            num_stages,
            num_laps,
            num_machines_per_stage,
            processing_times,
            due_dates,
            speed_levels,
            priorities,
            penalty_factors,
        ) = info
        num_speed_levels = len(speed_levels)

    return {
        "num_speed_levels": num_speed_levels,
        "num_factories": num_factories,
        "num_jobs": num_jobs,
        "num_stages": num_stages,
        "num_laps": num_laps,
        "num_machines_per_stage": num_machines_per_stage,
        "processing_times": processing_times,
        "due_dates": due_dates,
        "speed_levels": speed_levels,
        "priorities": priorities,
        "penalty_factors": penalty_factors,
    }


def _split_task_speed_levels(problem):
    speed_candidates = tuple(sorted(_problem_info(problem)["speed_levels"].keys()))
    q = len(speed_candidates)
    k, r = divmod(q, 3)

    if r == 0:
        low_size, middle_size, high_size = k, k, k
    elif r == 1:
        low_size, middle_size, high_size = k, k + 1, k
    else:
        low_size, middle_size, high_size = k + 1, k, k + 1

    low_end = low_size
    middle_end = low_end + middle_size

    groups = {
        "low": list(speed_candidates[:low_end]),
        "middle": list(speed_candidates[low_end:middle_end]),
        "high": list(speed_candidates[middle_end:]),
        "main": list(speed_candidates),
    }

    for task_name in ("low", "middle", "high"):
        if not groups[task_name]:
            raise ValueError(
                f"Speed group '{task_name}' is empty. Current speed levels: {speed_candidates}"
            )

    return groups


def _to_completion_list(completion_times):
    if completion_times is None:
        return None
    if hasattr(completion_times, "tolist"):
        return completion_times.tolist()
    return list(completion_times)


def _valid_speed_levels(problem):
    return set(_problem_info(problem)["speed_levels"].keys())


def _validate_speed_vector(problem, speed_vector):
    valid_levels = _valid_speed_levels(problem)
    for lap_idx, lap in enumerate(speed_vector):
        for job_idx, job_speeds in enumerate(lap):
            for stage_idx, level in enumerate(job_speeds):
                if level not in valid_levels:
                    raise ValueError(
                        f"Invalid speed level {level} at "
                        f"(lap={lap_idx}, job={job_idx}, stage={stage_idx}), "
                        f"valid levels={sorted(valid_levels)}"
                    )


def _batch_decode_and_cache(problem, individuals):
    if not individuals:
        return individuals

    for ind in individuals:
        _validate_speed_vector(problem, ind.speed_vector)

    job_sequences = [ind.job_sequence for ind in individuals]
    seq_lengths = [len(ind.job_sequence) for ind in individuals]
    factory_assignments = [ind.factory_assignment for ind in individuals]
    speed_vectors = [ind.speed_vector for ind in individuals]

    makespans, twts, tecs, completion_times_batch = decode_batch(
        problem,
        job_sequences,
        seq_lengths,
        factory_assignments,
        speed_vectors,
    )

    for i, ind in enumerate(individuals):
        ind.makespan = float(makespans[i])
        ind.TWT = float(twts[i])
        ind.TEC = float(tecs[i])
        if completion_times_batch is not None:
            ind.completion_times = _to_completion_list(completion_times_batch[i])

    return individuals


def init_transfer_q_learning(actions, config):
    return {
        "actions": list(actions),
        "q_table": {
            0: {a: 0.0 for a in actions},
            1: {a: 0.0 for a in actions},
        },
        "epsilon_start": config.q_epsilon_start,
        "epsilon_min": config.q_epsilon_min,
        "alpha": config.q_alpha,
        "gamma": config.q_gamma,
        "total_steps": 0,
        "action_stats": {
            action: {
                "attempts": 0,
                "reward_sum": 0.0,
                "best_reward": float("-inf"),
            }
            for action in actions
        },
    }


def _accept_transfer(points_before, points_after, eps=1e-12):
    if len(points_before) == 0:
        return True

    joint_min, joint_max = get_joint_min_max_from_points(points_before, points_after)
    reference_front = build_online_reference_front(points_before, points_after)

    igd_before = calculate_points_igd(
        points_before,
        reference_front,
        min_values=joint_min,
        max_values=joint_max,
    )
    igd_after = calculate_points_igd(
        points_after,
        reference_front,
        min_values=joint_min,
        max_values=joint_max,
    )

    return igd_after <= igd_before + eps


def _weighted_random_choice(actions, weights):
    total = sum(weights)
    if total <= 0.0:
        return random.choice(actions)

    r = random.random() * total
    cumulative = 0.0
    last_action = actions[-1]

    for action, weight in zip(actions, weights):
        cumulative += weight
        if r <= cumulative:
            return action
        last_action = action

    return last_action


def select_transfer_action_q(q_state, state, elapsed_time, total_time):
    actions = q_state["actions"]
    q_values = q_state["q_table"][state]
    values = [q_values[action] for action in actions]

    epsilon = get_time_based_epsilon(q_state, elapsed_time, total_time)

    if random.random() < epsilon:
        return random.choice(actions)

    q_min = min(values)
    q_max = max(values)
    if q_max == q_min:
        return random.choice(actions)

    denom = q_max - q_min
    weights = [((v - q_min) / denom) + 1e-6 for v in values]
    return _weighted_random_choice(actions, weights)


def get_time_based_epsilon(q_state, elapsed_time, total_time):
    progress = min(max(elapsed_time / max(total_time, 1e-12), 0.0), 1.0)
    epsilon_start = q_state["epsilon_start"]
    epsilon_min = q_state["epsilon_min"]
    epsilon = epsilon_start - (epsilon_start - epsilon_min) * progress
    return max(epsilon_min, epsilon)


def update_transfer_q_learning(q_state, state, action, reward, next_state):
    q_old = q_state["q_table"][state][action]
    next_max = max(q_state["q_table"][next_state].values())
    alpha = q_state["alpha"]
    gamma = q_state["gamma"]
    q_new = q_old + alpha * (reward + gamma * next_max - q_old)
    q_state["q_table"][state][action] = q_new
    q_state["total_steps"] += 1


def update_action_statistics(q_state, action, reward):
    stats = q_state["action_stats"][action]
    stats["attempts"] += 1
    stats["reward_sum"] += reward
    stats["best_reward"] = max(stats["best_reward"], reward)


def igd_state(igd_before, igd_after):
    return 1 if igd_after < igd_before else 0


def igd_reward(igd_before, igd_after):
    return igd_before - igd_after


if njit is not None:
    @njit(cache=True)
    def _dominates_row(a, b):
        strictly_better = False
        for k in range(a.shape[0]):
            if a[k] > b[k]:
                return False
            if a[k] < b[k]:
                strictly_better = True
        return strictly_better


    @njit(cache=True)
    def _non_dominated_mask(points):
        n = points.shape[0]
        mask = np.ones(n, dtype=np.uint8)
        for i in range(n):
            for j in range(n):
                if i == j:
                    continue
                if _dominates_row(points[j], points[i]):
                    mask[i] = 0
                    break
        return mask


    @njit(cache=True)
    def _normalize_points(points, min_values, max_values, eps=1e-12):
        n, m = points.shape
        out = np.empty((n, m), dtype=np.float64)

        for i in range(n):
            for j in range(m):
                denom = max_values[j] - min_values[j]
                if abs(denom) <= eps:
                    out[i, j] = 0.0
                else:
                    out[i, j] = (points[i, j] - min_values[j]) / denom
        return out


    @njit(cache=True)
    def _igd_core(reference_front, approximation_front):
        n_ref = reference_front.shape[0]
        n_pop = approximation_front.shape[0]
        total = 0.0

        for i in range(n_ref):
            best = 1e100
            for j in range(n_pop):
                s = 0.0
                for k in range(reference_front.shape[1]):
                    d = reference_front[i, k] - approximation_front[j, k]
                    s += d * d
                dist = np.sqrt(s)
                if dist < best:
                    best = dist
            total += best

        return total / n_ref


    @njit(cache=True)
    def _mean_point(points):
        m = points.shape[1]
        center = np.zeros(m, dtype=np.float64)
        n = points.shape[0]

        if n == 0:
            return center

        for i in range(n):
            for j in range(m):
                center[j] += points[i, j]

        for j in range(m):
            center[j] /= n

        return center


    @njit(cache=True)
    def _squared_distance_to_center(points, center):
        n = points.shape[0]
        m = points.shape[1]
        dist = np.empty(n, dtype=np.float64)

        for i in range(n):
            s = 0.0
            for j in range(m):
                d = points[i, j] - center[j]
                s += d * d
            dist[i] = s

        return dist
else:
    def _non_dominated_mask(points):
        n = len(points)
        mask = np.ones(n, dtype=np.uint8)
        for i in range(n):
            for j in range(n):
                if i == j:
                    continue
                a = points[j]
                b = points[i]
                if np.all(a <= b) and np.any(a < b):
                    mask[i] = 0
                    break
        return mask


    def _normalize_points(points, min_values, max_values, eps=1e-12):
        denom = np.maximum(max_values - min_values, eps)
        return (points - min_values) / denom


    def _igd_core(reference_front, approximation_front):
        diff = reference_front[:, None, :] - approximation_front[None, :, :]
        dist = np.sqrt(np.sum(diff * diff, axis=2))
        return float(np.mean(np.min(dist, axis=1)))


    def _mean_point(points):
        if len(points) == 0:
            return np.zeros(3, dtype=np.float64)
        return np.mean(points, axis=0)


    def _squared_distance_to_center(points, center):
        diff = points - center
        return np.sum(diff * diff, axis=1)


def _population_to_points(population):
    n = len(population)
    points = np.empty((n, 3), dtype=np.float64)
    for i, sol in enumerate(population):
        points[i, 0] = sol.makespan
        points[i, 1] = sol.TWT
        points[i, 2] = sol.TEC
    return points


def _task_candidates(problem, task_name):
    return _split_task_speed_levels(problem)[task_name]


def _remap_speed_vector_to_task(problem, speed_vector, task_name):
    candidates = _task_candidates(problem, task_name)
    candidate_set = set(candidates)
    mapped = []
    for lap in speed_vector:
        new_lap = []
        for job_speeds in lap:
            new_job = []
            for speed in job_speeds:
                if speed in candidate_set:
                    new_job.append(speed)
                else:
                    new_job.append(random.choice(candidates))
            new_lap.append(new_job)
        mapped.append(new_lap)
    return mapped


def _clone_solution(individual, problem=None, target_task_type=None, remap_speed=False):
    child = copy.copy(individual)

    if hasattr(individual, "job_sequence") and individual.job_sequence is not None:
        child.job_sequence = individual.job_sequence[:]
    if hasattr(individual, "factory_assignment") and individual.factory_assignment is not None:
        child.factory_assignment = individual.factory_assignment[:]
    if hasattr(individual, "completion_times") and individual.completion_times is not None:
        child.completion_times = individual.completion_times[:]
    if hasattr(individual, "speed_vector") and individual.speed_vector is not None:
        if remap_speed and problem is not None and target_task_type is not None:
            child.speed_vector = _remap_speed_vector_to_task(problem, individual.speed_vector, target_task_type)
        else:
            child.speed_vector = copy.deepcopy(individual.speed_vector)

    if target_task_type is not None:
        child.task_type = target_task_type
    return child


def unique_nd_front(points):
    points = np.asarray(points, dtype=np.float64)
    if points.size == 0:
        return points.reshape(0, 3)

    mask = _non_dominated_mask(points)
    nd_points = points[mask == 1]
    return np.unique(nd_points, axis=0)


def get_nondominated_solutions(population):
    if not population:
        return []

    points = _population_to_points(population)
    mask = _non_dominated_mask(points)
    return [population[i] for i in range(len(population)) if mask[i] == 1]


def _get_rank0_solutions(population):
    rank0 = [ind for ind in population if getattr(ind, "rank", None) == 0]
    if rank0:
        return rank0
    return get_nondominated_solutions(population)


def get_population_points(population):
    if not population:
        return np.empty((0, 3), dtype=np.float64)
    return _population_to_points(population)


def get_joint_min_max_from_points(points_a, points_b):
    points_a = np.asarray(points_a, dtype=np.float64).reshape(-1, 3)
    points_b = np.asarray(points_b, dtype=np.float64).reshape(-1, 3)

    if len(points_a) == 0 and len(points_b) == 0:
        zeros = np.zeros(3, dtype=np.float64)
        return zeros, zeros
    if len(points_a) == 0:
        return points_b.min(axis=0), points_b.max(axis=0)
    if len(points_b) == 0:
        return points_a.min(axis=0), points_a.max(axis=0)

    min_values = np.minimum(points_a.min(axis=0), points_b.min(axis=0))
    max_values = np.maximum(points_a.max(axis=0), points_b.max(axis=0))
    return min_values, max_values


def build_online_reference_front(points_before, points_after):
    points_before = np.asarray(points_before, dtype=np.float64).reshape(-1, 3)
    points_after = np.asarray(points_after, dtype=np.float64).reshape(-1, 3)

    if len(points_before) == 0:
        union_points = points_after
    elif len(points_after) == 0:
        union_points = points_before
    else:
        union_points = np.vstack((points_before, points_after))

    return unique_nd_front(union_points)


def calculate_points_igd(points, reference_front, min_values=None, max_values=None):
    points = np.asarray(points, dtype=np.float64).reshape(-1, 3)
    reference_front = np.asarray(reference_front, dtype=np.float64).reshape(-1, 3)

    if len(points) == 0 or len(reference_front) == 0:
        return float("inf")

    if min_values is None:
        min_values = np.minimum(points.min(axis=0), reference_front.min(axis=0))
    else:
        min_values = np.asarray(min_values, dtype=np.float64)

    if max_values is None:
        max_values = np.maximum(points.max(axis=0), reference_front.max(axis=0))
    else:
        max_values = np.asarray(max_values, dtype=np.float64)

    norm_points = _normalize_points(points, min_values, max_values)
    norm_ref = _normalize_points(reference_front, min_values, max_values)
    return float(_igd_core(norm_ref, norm_points))


def _topk_smallest_indices(values, k):
    n = values.shape[0]
    if n == 0 or k <= 0:
        return np.empty(0, dtype=np.int64)

    k = min(k, n)
    if k == n:
        return np.argsort(values).astype(np.int64)

    idx = np.argpartition(values, k - 1)[:k]
    return idx[np.argsort(values[idx])].astype(np.int64)


def _select_boundary_migrants(
    problem,
    source_population,
    source_points,
    target_population,
    target_points,
    transfer_ratio,
    target_task_type,
    remap_speed,
):
    if not source_population or not target_population:
        return [], np.empty((0, 3), dtype=np.float64)

    source_candidates = _get_rank0_solutions(source_population)
    if not source_candidates:
        source_candidates = source_population

    if len(source_candidates) == len(source_population):
        source_candidate_points = source_points
    else:
        source_candidate_points = _population_to_points(source_candidates)

    min_values, max_values = get_joint_min_max_from_points(source_candidate_points, target_points)
    source_norm = _normalize_points(source_candidate_points, min_values, max_values)
    target_norm = _normalize_points(target_points, min_values, max_values)

    target_center = _mean_point(target_norm)
    distances = _squared_distance_to_center(source_norm, target_center)

    transfer_count = max(1, int(len(target_population) * transfer_ratio))
    chosen_indices = _topk_smallest_indices(distances, transfer_count)

    migrants = []
    for idx in chosen_indices.tolist():
        migrant = _clone_solution(
            source_candidates[int(idx)],
            problem=problem,
            target_task_type=target_task_type,
            remap_speed=remap_speed,
        )
        migrants.append(migrant)

    _batch_decode_and_cache(problem, migrants)
    migrant_points = _population_to_points(migrants) if migrants else np.empty((0, 3), dtype=np.float64)

    return migrants, migrant_points


def _deduplicate_population_and_points(population, points, ndigits=12):
    if not population:
        return [], np.empty((0, 3), dtype=np.float64)

    unique_population = []
    unique_points = []
    seen = set()
    scale = 10 ** ndigits

    for ind, point in zip(population, points):
        key = (
            int(round(float(point[0]) * scale)),
            int(round(float(point[1]) * scale)),
            int(round(float(point[2]) * scale)),
        )
        if key in seen:
            continue
        seen.add(key)
        unique_population.append(ind)
        unique_points.append(point)

    if unique_points:
        unique_points = np.asarray(unique_points, dtype=np.float64)
    else:
        unique_points = np.empty((0, 3), dtype=np.float64)

    return unique_population, unique_points


def directed_knowledge_transfer_light(
    problem,
    source_population,
    target_population,
    target_task_type,
    source_points,
    target_points,
    transfer_ratio,
    remap_speed=False,
):
    migrants, migrant_points = _select_boundary_migrants(
        problem,
        source_population,
        source_points,
        target_population,
        target_points,
        transfer_ratio,
        target_task_type,
        remap_speed,
    )
    if not migrants:
        return target_population, target_points

    merged_population = list(target_population)
    merged_population.extend(migrants)
    merged_points = np.vstack((target_points, migrant_points))

    return _deduplicate_population_and_points(merged_population, merged_points)


def _apply_one_way_transfer(problem, source_population, target_population, target_task_type, transfer_ratio, remap_speed):
    before_points = get_population_points(target_population)
    source_points = get_population_points(source_population)

    candidate_task, candidate_points = directed_knowledge_transfer_light(
        problem,
        source_population,
        target_population,
        target_task_type=target_task_type,
        source_points=source_points,
        target_points=before_points,
        transfer_ratio=transfer_ratio,
        remap_speed=remap_speed,
    )

    if _accept_transfer(before_points, candidate_points):
        return candidate_task, candidate_points, before_points, candidate_points
    return target_population, before_points, before_points, before_points

def _apply_one_way_transfer_PR(problem, source_population, target_population, target_task_type, transfer_ratio, remap_speed):
    before_points = get_population_points(target_population)
    source_points = get_population_points(source_population)

    candidate_task, candidate_points = directed_knowledge_transfer_light(
        problem,
        source_population,
        target_population,
        target_task_type=target_task_type,
        source_points=source_points,
        target_points=before_points,
        transfer_ratio=transfer_ratio,
        remap_speed=remap_speed,
    )

    return candidate_task, candidate_points, before_points, candidate_points


def apply_bidirectional_transfer(
    problem,
    action,
    low_speed_task,
    middle_speed_task,
    high_speed_task,
    main_task,
    transfer_ratio,
):
    before_points = np.empty((0, 3), dtype=np.float64)
    after_points = before_points

    if action == "l2main":
        main_task, _, before_points, after_points = _apply_one_way_transfer(
            problem, low_speed_task, main_task, "main", transfer_ratio, remap_speed=False
        )
    elif action == "mid2main":
        main_task, _, before_points, after_points = _apply_one_way_transfer(
            problem, middle_speed_task, main_task, "main", transfer_ratio, remap_speed=False
        )

    elif action == "h2main":
        main_task, _, before_points, after_points = _apply_one_way_transfer(
            problem, high_speed_task, main_task, "main", transfer_ratio, remap_speed=False
        )
    elif action == "main2l":
        low_speed_task, _, before_points, after_points = _apply_one_way_transfer(
            problem, main_task, low_speed_task, "low", transfer_ratio, remap_speed=True
        )
    elif action == "main2mid":
        middle_speed_task, _, before_points, after_points = _apply_one_way_transfer(
            problem, main_task, middle_speed_task, "middle", transfer_ratio, remap_speed=True
        )
    elif action == "main2h":
        high_speed_task, _, before_points, after_points = _apply_one_way_transfer(
            problem, main_task, high_speed_task, "high", transfer_ratio, remap_speed=True
        )

    return low_speed_task, middle_speed_task, high_speed_task, main_task, before_points, after_points


def apply_bidirectional_transfer_PR(
    problem,
    action,
    low_speed_task,
    middle_speed_task,
    high_speed_task,
    main_task,
    transfer_ratio,
):
    before_points = np.empty((0, 3), dtype=np.float64)
    after_points = before_points

    if action == "l2main":
        main_task, _, before_points, after_points = _apply_one_way_transfer_PR(
            problem, low_speed_task, main_task, "main", transfer_ratio, remap_speed=False
        )
    elif action == "mid2main":
        main_task, _, before_points, after_points = _apply_one_way_transfer_PR(
            problem, middle_speed_task, main_task, "main", transfer_ratio, remap_speed=False
        )

    elif action == "h2main":
        main_task, _, before_points, after_points = _apply_one_way_transfer_PR(
            problem, high_speed_task, main_task, "main", transfer_ratio, remap_speed=False
        )
    elif action == "main2l":
        low_speed_task, _, before_points, after_points = _apply_one_way_transfer_PR(
            problem, main_task, low_speed_task, "low", transfer_ratio, remap_speed=True
        )
    elif action == "main2mid":
        middle_speed_task, _, before_points, after_points = _apply_one_way_transfer_PR(
            problem, main_task, middle_speed_task, "middle", transfer_ratio, remap_speed=True
        )
    elif action == "main2h":
        high_speed_task, _, before_points, after_points = _apply_one_way_transfer_PR(
            problem, main_task, high_speed_task, "high", transfer_ratio, remap_speed=True
        )

    return low_speed_task, middle_speed_task, high_speed_task, main_task, before_points, after_points

def apply_random_knowledge_transfer(
    problem,
    low_speed_task,
    middle_speed_task,
    high_speed_task,
    main_task,
    transfer_ratio=0.2,
):
    actions = (
        "l2main",
        "mid2main",
        "h2main",
        "main2l",
        "main2mid",
        "main2h",
    )

    action = random.choice(actions)

    if action == "l2main":
        source_population = low_speed_task
        target_population = main_task
        target_task_type = "main"
        remap_speed = False
        new_target, _ = directed_knowledge_transfer_light(
            problem,
            source_population,
            target_population,
            target_task_type,
            get_population_points(source_population),
            get_population_points(target_population),
            transfer_ratio,
            remap_speed=remap_speed,
        )
        main_task = new_target

    elif action == "mid2main":
        new_target, _ = directed_knowledge_transfer_light(
            problem,
            middle_speed_task,
            main_task,
            "main",
            get_population_points(middle_speed_task),
            get_population_points(main_task),
            transfer_ratio,
            remap_speed=False,
        )
        main_task = new_target

    elif action == "h2main":
        new_target, _ = directed_knowledge_transfer_light(
            problem,
            high_speed_task,
            main_task,
            "main",
            get_population_points(high_speed_task),
            get_population_points(main_task),
            transfer_ratio,
            remap_speed=False,
        )
        main_task = new_target

    elif action == "main2l":
        new_target, _ = directed_knowledge_transfer_light(
            problem,
            main_task,
            low_speed_task,
            "low",
            get_population_points(main_task),
            get_population_points(low_speed_task),
            transfer_ratio,
            remap_speed=True,
        )
        low_speed_task = new_target

    elif action == "main2mid":
        new_target, _ = directed_knowledge_transfer_light(
            problem,
            main_task,
            middle_speed_task,
            "middle",
            get_population_points(main_task),
            get_population_points(middle_speed_task),
            transfer_ratio,
            remap_speed=True,
        )
        middle_speed_task = new_target

    elif action == "main2h":
        new_target, _ = directed_knowledge_transfer_light(
            problem,
            main_task,
            high_speed_task,
            "high",
            get_population_points(main_task),
            get_population_points(high_speed_task),
            transfer_ratio,
            remap_speed=True,
        )
        high_speed_task = new_target

    return action, low_speed_task, middle_speed_task, high_speed_task, main_task
