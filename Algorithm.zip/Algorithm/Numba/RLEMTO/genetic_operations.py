import math
import random
from copy import deepcopy

from Algorithm.Numba.RLEMTO.Solution import Solution
from Algorithm.Numba.RLEMTO.decode import decode, decode_batch


def _to_completion_list(completion_times):
    if completion_times is None:
        return None
    if hasattr(completion_times, "tolist"):
        return completion_times.tolist()
    return list(completion_times)


def _split_speed_groups(problem):
    speed_candidates = sorted(problem.speed_levels.keys())
    q = len(speed_candidates)
    k, r = divmod(q, 3)

    if r == 0:
        low_size, middle_size, high_size = k, k, k
    elif r == 1:
        low_size, middle_size, high_size = k, k + 1, k
    else:
        low_size, middle_size, high_size = k + 1, k, k + 1

    low_end = low_size
    middle_end = low_end + middle_size

    groups = {
        "low": speed_candidates[:low_end],
        "middle": speed_candidates[low_end:middle_end],
        "high": speed_candidates[middle_end:],
        "main": speed_candidates[:],
    }

    return groups


def batch_evaluate(problem, individuals):
    if not individuals:
        return individuals

    job_sequences = []
    seq_lengths = []
    factory_assignments = []
    speed_vectors = []

    for ind in individuals:
        job_sequences.append(ind.job_sequence)
        seq_lengths.append(len(ind.job_sequence))
        factory_assignments.append(ind.factory_assignment)
        speed_vectors.append(ind.speed_vector)

    batch_result = decode_batch(
        problem,
        job_sequences,
        seq_lengths,
        factory_assignments,
        speed_vectors,
    )

    makespans, twts, tecs, completion_times_batch = batch_result

    for i, ind in enumerate(individuals):
        ind.makespan = float(makespans[i])
        ind.TWT = float(twts[i])
        ind.TEC = float(tecs[i])

        if completion_times_batch is not None:
            ind.completion_times = _to_completion_list(completion_times_batch[i])
        else:
            _, _, _, completion_times = decode(
                problem=problem,
                job_sequence=ind.job_sequence,
                factory_assignment=ind.factory_assignment,
                speed_vector=ind.speed_vector,
                return_details=True,
            )
            ind.completion_times = _to_completion_list(completion_times)

    return individuals


def objective_vector(individual):
    return [individual.makespan, individual.TWT, individual.TEC]


def dominates(a, b):
    a_obj = objective_vector(a)
    b_obj = objective_vector(b)
    no_worse = True
    strictly_better = False
    for x, y in zip(a_obj, b_obj):
        if x > y:
            no_worse = False
            break
        if x < y:
            strictly_better = True
    return no_worse and strictly_better


def get_ideal_point(population):
    n_obj = len(objective_vector(population[0]))
    ideal = [float("inf")] * n_obj
    for ind in population:
        values = objective_vector(ind)
        for i in range(n_obj):
            ideal[i] = min(ideal[i], values[i])
    return ideal


def get_nadir_point(population):
    n_obj = len(objective_vector(population[0]))
    nadir = [float("-inf")] * n_obj
    for ind in population:
        values = objective_vector(ind)
        for i in range(n_obj):
            nadir[i] = max(nadir[i], values[i])
    return nadir


def normalized_objectives(ind, ideal_point, nadir_point):
    return [
        (ind.makespan - ideal_point[0]) /
        (nadir_point[0] - ideal_point[0] + 1e-12),
        (ind.TWT - ideal_point[1]) /
        (nadir_point[1] - ideal_point[1] + 1e-12),
        (ind.TEC - ideal_point[2]) /
        (nadir_point[2] - ideal_point[2] + 1e-12),
    ]


def distance_to_ideal(ind, ideal_point, nadir_point):
    f = normalized_objectives(ind, ideal_point, nadir_point)
    return math.sqrt(sum(x * x for x in f))


def binary_tournament(a, b, ideal_point, nadir_point):
    if dominates(a, b):
        return a
    if dominates(b, a):
        return b

    da = distance_to_ideal(a, ideal_point, nadir_point)
    db = distance_to_ideal(b, ideal_point, nadir_point)
    if da <= db:
        return a
    return b


def tournament_selection(population, mating_pool_size, ideal_point, nadir_point):
    mating_pool = []
    for _ in range(mating_pool_size):
        a, b = random.sample(population, 2)
        mating_pool.append(binary_tournament(a, b, ideal_point, nadir_point))
    return mating_pool

def pox_crossover(job_seq1, job_seq2):
    size = len(job_seq1)

    selected_jobs_1 = set(random.sample(job_seq1, random.randint(1, max(1, size // 2))))
    child1 = [-1] * size

    for i in range(size):
        if job_seq1[i] in selected_jobs_1:
            child1[i] = job_seq1[i]

    fill_values_1 = [job for job in job_seq2 if job not in selected_jobs_1]
    fill_idx_1 = 0
    for i in range(size):
        if child1[i] == -1:
            child1[i] = fill_values_1[fill_idx_1]
            fill_idx_1 += 1

    selected_jobs_2 = set(random.sample(job_seq2, random.randint(1, max(1, size // 2))))
    child2 = [-1] * size

    for i in range(size):
        if job_seq2[i] in selected_jobs_2:
            child2[i] = job_seq2[i]

    fill_values_2 = [job for job in job_seq1 if job not in selected_jobs_2]
    fill_idx_2 = 0
    for i in range(size):
        if child2[i] == -1:
            child2[i] = fill_values_2[fill_idx_2]
            fill_idx_2 += 1

    return child1, child2

# def pox_crossover(job_seq1, job_seq2):
#     size = len(job_seq1)
#     selected_jobs = set(random.sample(job_seq1, random.randint(1, max(1, size // 2))))
#     # child1: 保留 parent1 中 selected_jobs 的位置
#     child1 = [-1] * size
#     for i in range(size):
#         if job_seq1[i] in selected_jobs:
#             child1[i] = job_seq1[i]
#     fill1 = [job for job in job_seq2 if job not in selected_jobs]
#     idx = 0
#     for i in range(size):
#         if child1[i] == -1:
#             child1[i] = fill1[idx]
#             idx += 1
#     # child2: 保留 parent2 中 not selected_jobs 的位置
#     child2 = [-1] * size
#     for i in range(size):
#         if job_seq2[i] not in selected_jobs:
#             child2[i] = job_seq2[i]
#     fill2 = [job for job in job_seq1 if job in selected_jobs]
#     idx = 0
#     for i in range(size):
#         if child2[i] == -1:
#             child2[i] = fill2[idx]
#             idx += 1
#     return child1, child2


def uniform_crossover(fa1, fa2):
    child1 = []
    child2 = []

    for f1, f2 in zip(fa1, fa2):
        if random.random() < 0.5:
            child1.append(f1)
            child2.append(f2)
        else:
            child1.append(f2)
            child2.append(f1)

    return child1, child2


def speed_crossover(speed1, speed2):
    child1 = deepcopy(speed1)
    child2 = deepcopy(speed2)
    for lap in range(len(speed1)):
        for job in range(len(speed1[lap])):
            for stage in range(len(speed1[lap][job])):
                if random.random() < 0.5:
                    child1[lap][job][stage], child2[lap][job][stage] = (child2[lap][job][stage], child1[lap][job][stage],)
    return child1, child2


def crossover_variable_speed_task(parent1, parent2, crossover_prob):
    if random.random() > crossover_prob:
        return deepcopy(parent1), deepcopy(parent2)

    child1_seq, child2_seq = pox_crossover(parent1.job_sequence, parent2.job_sequence)
    child1_factory, child2_factory = uniform_crossover(parent1.factory_assignment, parent2.factory_assignment)
    child1_speed, child2_speed = speed_crossover(parent1.speed_vector, parent2.speed_vector)
    child1 = Solution(makespan=0.0, TWT=0.0, TEC=0.0, job_sequence=child1_seq, factory_assignment=child1_factory, speed_vector=child1_speed, completion_times=None,)
    child2 = Solution(makespan=0.0, TWT=0.0, TEC=0.0, job_sequence=child2_seq, factory_assignment=child2_factory, speed_vector=child2_speed, completion_times=None,)
    return child1, child2


def mutate_job_sequence(job_sequence):
    i, j = sorted(random.sample(range(len(job_sequence)), 2))
    job_sequence[i], job_sequence[j] = job_sequence[j], job_sequence[i]


def mutate_factory_assignment(factory_assignment, num_factories):
    index = random.randrange(len(factory_assignment))
    factory_assignment[index] = random.randrange(num_factories)


def mutate_speed_vector(speed_vector, speed_candidates):
    lap = random.randrange(len(speed_vector))
    job = random.randrange(len(speed_vector[lap]))
    stage = random.randrange(len(speed_vector[lap][job]))
    speed_vector[lap][job][stage] = random.choice(speed_candidates)


def get_task_speed_candidates(problem, task_name):
    speed_groups = _split_speed_groups(problem)
    return speed_groups[task_name]


def mutation_by_task(problem, individual, mutation_prob, task_name):
    mutant = deepcopy(individual)
    speed_candidates = get_task_speed_candidates(problem, task_name)

    if random.random() < mutation_prob:
        mutate_job_sequence(mutant.job_sequence)
    if random.random() < mutation_prob:
        mutate_factory_assignment(mutant.factory_assignment, problem.num_factorys)
    if random.random() < mutation_prob:
        mutate_speed_vector(mutant.speed_vector, speed_candidates)

    return mutant


def generate_offspring_by_task(problem, population, Config, task_name):
    popsize = len(population)
    crossover_prob = Config.crossover_prob
    mutation_prob = Config.mutation_prob
    ideal_point = get_ideal_point(population)
    nadir_point = get_nadir_point(population)
    mating_pool = tournament_selection(population, popsize, ideal_point, nadir_point)
    offspring = []

    for i in range(0, popsize, 2):
        parent1 = mating_pool[i]
        parent2 = mating_pool[(i + 1) % popsize]

        child1, child2 = crossover_variable_speed_task(parent1, parent2, crossover_prob)

        child1 = mutation_by_task(problem, child1, mutation_prob, task_name)
        child2 = mutation_by_task(problem, child2, mutation_prob, task_name)

        offspring.append(child1)
        if len(offspring) < popsize:
            offspring.append(child2)

    return batch_evaluate(problem, offspring) + population
