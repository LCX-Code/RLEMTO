from dataclasses import dataclass, field
from typing import List, Optional


@dataclass(frozen=True)
class OperationRecord:
    factory: int
    lap: int
    stage: int
    job: int
    machine: int
    finish: float
    speed: float


@dataclass
class Solution:
    makespan: float
    TWT: float
    TEC: float
    job_sequence: List[int]
    factory_assignment: List[int]
    speed_vector: List[List[List[int]]]
    completion_times: Optional[List[float]] = field(default=None)
    gantt_records: Optional[List[OperationRecord]] = field(default=None)
