import numpy as np

try:
    from numba import njit
except ImportError:  # pragma: no cover
    def njit(*args, **kwargs):
        def wrapper(func):
            return func
        return wrapper


@njit(cache=True, inline="always")
def _dominates_row(a0, a1, a2, b0, b1, b2):
    return (
        a0 <= b0 and a1 <= b1 and a2 <= b2
        and (a0 < b0 or a1 < b1 or a2 < b2)
    )


@njit(cache=True)
def _fast_non_dominated_sort_core(objs):
    n = objs.shape[0]
    dominated_count = np.zeros(n, dtype=np.int32)
    dominates_matrix = np.zeros((n, n), dtype=np.uint8)

    for i in range(n):
        a0 = objs[i, 0]
        a1 = objs[i, 1]
        a2 = objs[i, 2]
        for j in range(i + 1, n):
            b0 = objs[j, 0]
            b1 = objs[j, 1]
            b2 = objs[j, 2]

            if _dominates_row(a0, a1, a2, b0, b1, b2):
                dominates_matrix[i, j] = 1
                dominated_count[j] += 1
            elif _dominates_row(b0, b1, b2, a0, a1, a2):
                dominates_matrix[j, i] = 1
                dominated_count[i] += 1

    rank = -np.ones(n, dtype=np.int32)
    current_front = np.empty(n, dtype=np.int32)
    current_size = 0

    for i in range(n):
        if dominated_count[i] == 0:
            rank[i] = 0
            current_front[current_size] = i
            current_size += 1

    fronts = []
    front_rank = 0

    while current_size > 0:
        front = current_front[:current_size].copy()
        fronts.append(front)

        next_front = np.empty(n, dtype=np.int32)
        next_size = 0

        for idx in range(current_size):
            p = current_front[idx]
            for q in range(n):
                if dominates_matrix[p, q] == 1:
                    dominated_count[q] -= 1
                    if dominated_count[q] == 0 and rank[q] == -1:
                        rank[q] = front_rank + 1
                        next_front[next_size] = q
                        next_size += 1

        current_front = next_front
        current_size = next_size
        front_rank += 1

    return rank, fronts


@njit(cache=True)
def _pairwise_min_distance_to_selected_core(candidates, selected_points):
    n = candidates.shape[0]
    m = selected_points.shape[0]
    result = np.empty(n, dtype=np.float64)

    if m == 0:
        for i in range(n):
            result[i] = np.inf
        return result

    for i in range(n):
        best = 1e100
        c0 = candidates[i, 0]
        c1 = candidates[i, 1]
        c2 = candidates[i, 2]
        for j in range(m):
            d0 = c0 - selected_points[j, 0]
            d1 = c1 - selected_points[j, 1]
            d2 = c2 - selected_points[j, 2]
            dist2 = d0 * d0 + d1 * d1 + d2 * d2
            if dist2 < best:
                best = dist2
        result[i] = np.sqrt(best)
    return result


def _extract_objective_matrix(population):
    objs = np.empty((len(population), 3), dtype=np.float64)
    for i, ind in enumerate(population):
        objs[i, 0] = ind.makespan
        objs[i, 1] = ind.TWT
        objs[i, 2] = ind.TEC
    return objs


def non_dominated_sort(population):
    if not population:
        return []

    objs = _extract_objective_matrix(population)
    rank, fronts = _fast_non_dominated_sort_core(objs)

    result = []
    for front in fronts:
        current = []
        for idx in front:
            idx = int(idx)
            population[idx].rank = int(rank[idx])
            current.append(population[idx])
        if current:
            result.append(current)
    return result


def _normalize_objectives_matrix(objs, ideal_point, nadir_point, eps=1e-12):
    scale = nadir_point - ideal_point
    scale = np.maximum(scale, eps)
    return (objs - ideal_point) / scale


def _convergence_distance_batch(normalized_objs):
    return np.sqrt(np.sum(normalized_objs * normalized_objs, axis=1))


def _simplex_projection_batch(normalized_objs, eps=1e-12):
    totals = np.sum(normalized_objs, axis=1, keepdims=True)
    projected = np.empty_like(normalized_objs)

    zero_mask = totals[:, 0] <= eps
    nonzero_mask = ~zero_mask

    if np.any(nonzero_mask):
        projected[nonzero_mask] = normalized_objs[nonzero_mask] / totals[nonzero_mask]
    if np.any(zero_mask):
        projected[zero_mask] = 1.0 / 3.0

    return projected


def _min_max_normalize_array(values, eps=1e-12):
    if values.size == 0:
        return values.copy()

    v_min = float(np.min(values))
    v_max = float(np.max(values))
    if abs(v_max - v_min) <= eps:
        return np.zeros_like(values)
    return (values - v_min) / (v_max - v_min + eps)


def _environmental_selection(population, popsize, Config, elapsed_time):
    radius = Config.radius
    total_time = Config.g_time

    if len(population) <= popsize:
        return population

    fronts = non_dominated_sort(population)
    next_population = []
    last_front = []

    for front in fronts:
        if len(next_population) + len(front) <= popsize:
            next_population.extend(front)
        else:
            last_front = front
            break

    if len(next_population) == popsize or not last_front:
        return next_population[:popsize]

    union = next_population + last_front
    union_objs = _extract_objective_matrix(union)
    ideal_point = np.min(union_objs, axis=0)
    nadir_point = np.max(union_objs, axis=0)

    offset = len(next_population)
    last_front_objs = union_objs[offset:]
    normalized = _normalize_objectives_matrix(last_front_objs, ideal_point, nadir_point)
    convergence = _convergence_distance_batch(normalized)
    simplex = _simplex_projection_batch(normalized)

    selected_set = list(next_population)
    m = len(last_front)
    selected_mask = np.zeros(m, dtype=bool)
    active_mask = np.ones(m, dtype=bool)
    removed_mask = np.zeros(m, dtype=bool)

    selected_projection_points = np.empty((popsize, 3), dtype=np.float64)
    selected_proj_count = 0

    extreme_indices = []
    for objective_index in range(3):
        local_idx = int(np.argmin(last_front_objs[:, objective_index]))
        if not selected_mask[local_idx]:
            selected_mask[local_idx] = True
            extreme_indices.append(local_idx)

    remaining_slots = popsize - len(next_population)
    for idx in extreme_indices:
        if remaining_slots <= 0:
            break
        selected_set.append(last_front[idx])
        active_mask[idx] = False
        selected_projection_points[selected_proj_count] = simplex[idx]
        selected_proj_count += 1
        remaining_slots -= 1

    if selected_proj_count == 0 and next_population:
        next_objs = union_objs[:offset]
        next_normalized = _normalize_objectives_matrix(next_objs, ideal_point, nadir_point)
        next_simplex = _simplex_projection_batch(next_normalized)
        copy_count = min(next_simplex.shape[0], popsize)
        selected_projection_points[:copy_count] = next_simplex[:copy_count]
        selected_proj_count = copy_count

    projected_dispersion = _pairwise_min_distance_to_selected_core(
        simplex,
        selected_projection_points[:selected_proj_count],
    )

    progress = min(max(elapsed_time / total_time, 0.0), 1.0)
    alpha_t = max(1.0 - progress, 0.5)
    beta_t = max(progress, 0.5)

    while len(selected_set) < popsize:
        active_indices = np.flatnonzero(active_mask & (~selected_mask))

        if active_indices.size == 0:
            refill_mask = removed_mask & (~selected_mask)
            if not np.any(refill_mask):
                break

            active_mask = refill_mask.copy()
            removed_mask[:] = False
            active_indices = np.flatnonzero(active_mask & (~selected_mask))
            if active_indices.size == 0:
                break

            projected_dispersion[active_indices] = _pairwise_min_distance_to_selected_core(
                simplex[active_indices],
                selected_projection_points[:selected_proj_count],
            )

        active_conv = convergence[active_indices]
        active_disp = projected_dispersion[active_indices]
        conv_norm = _min_max_normalize_array(active_conv)
        disp_norm = _min_max_normalize_array(active_disp)
        scores = alpha_t * conv_norm - beta_t * disp_norm

        best_local = int(np.argmin(scores))
        best_score = scores[best_local]
        tie_indices = np.flatnonzero(np.abs(scores - best_score) <= 1e-12)
        if tie_indices.size > 1:
            best_local = int(tie_indices[np.argmin(conv_norm[tie_indices])])

        chosen_idx = int(active_indices[best_local])
        selected_mask[chosen_idx] = True
        active_mask[chosen_idx] = False
        selected_set.append(last_front[chosen_idx])

        chosen_simplex = simplex[chosen_idx]
        selected_projection_points[selected_proj_count] = chosen_simplex
        selected_proj_count += 1

        remaining_indices = np.flatnonzero(active_mask & (~selected_mask))
        if remaining_indices.size == 0:
            continue

        diff = simplex[remaining_indices] - chosen_simplex
        dist = np.sqrt(np.sum(diff * diff, axis=1))

        close_mask = dist < radius
        if np.any(close_mask):
            close_indices = remaining_indices[close_mask]
            removed_mask[close_indices] = True
            active_mask[close_indices] = False

        far_indices = remaining_indices[~close_mask]
        if far_indices.size > 0:
            projected_dispersion[far_indices] = np.minimum(
                projected_dispersion[far_indices],
                dist[~close_mask],
            )

    return selected_set[:popsize]


def environmental_selection_by_task(population, Config, elapsed_time, task_name):
    task_size_map = {
        "low": Config.low_speed_task_size,
        "middle": Config.middle_speed_task_size,
        "high": Config.high_speed_task_size,
        "main": Config.main_speed_task_size,
    }

    return _environmental_selection(
        population,
        task_size_map[task_name],
        Config,
        elapsed_time,
    )
