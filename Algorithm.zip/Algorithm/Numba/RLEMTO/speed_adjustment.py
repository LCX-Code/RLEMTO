import random
from copy import deepcopy

from Algorithm.Numba.RLEMTO.local_search_operators import decode_with_critical_path
from Algorithm.Numba.RLEMTO.decode import decode_batch, decode


def _problem_info(problem):
    info = problem.info
    if len(info) == 11:
        (
            num_speed_levels,
            num_factories,
            num_jobs,
            num_stages,
            num_laps,
            num_machines_per_stage,
            processing_times,
            due_dates,
            speed_levels,
            priorities,
            penalty_factors,
        ) = info
    else:
        (
            num_factories,
            num_jobs,
            num_stages,
            num_laps,
            num_machines_per_stage,
            processing_times,
            due_dates,
            speed_levels,
            priorities,
            penalty_factors,
        ) = info
        num_speed_levels = len(speed_levels)

    return {
        "num_speed_levels": num_speed_levels,
        "num_factories": num_factories,
        "num_jobs": num_jobs,
        "num_stages": num_stages,
        "num_laps": num_laps,
        "num_machines_per_stage": num_machines_per_stage,
        "processing_times": processing_times,
        "due_dates": due_dates,
        "speed_levels": speed_levels,
        "priorities": priorities,
        "penalty_factors": penalty_factors,
    }


def _safe_speed_level(speed_vector, lap, job, stage):
    if lap < 0 or lap >= len(speed_vector):
        return None
    lap_data = speed_vector[lap]
    if job < 0 or job >= len(lap_data):
        return None
    job_data = lap_data[job]
    if stage < 0 or stage >= len(job_data):
        return None
    return job_data[stage]


def _to_completion_list(completion_times):
    if isinstance(completion_times, dict):
        completion_times = completion_times.get("completion_times", [])
    if hasattr(completion_times, "tolist"):
        return completion_times.tolist()
    return list(completion_times)


def _batch_decode_and_cache(problem, individuals):
    if not individuals:
        return individuals

    job_sequences = [ind.job_sequence for ind in individuals]
    seq_lengths = [len(ind.job_sequence) for ind in individuals]
    factory_assignments = [ind.factory_assignment for ind in individuals]
    speed_vectors = [ind.speed_vector for ind in individuals]

    makespans, twts, tecs, completion_times_batch = decode_batch(
        problem,
        job_sequences,
        seq_lengths,
        factory_assignments,
        speed_vectors,
    )

    for i, ind in enumerate(individuals):
        ind.makespan = float(makespans[i])
        ind.TWT = float(twts[i])
        ind.TEC = float(tecs[i])

        if completion_times_batch is not None:
            ind.completion_times = _to_completion_list(completion_times_batch[i])
        else:
            _, _, _, completion_times = decode(
                problem,
                ind.job_sequence,
                ind.factory_assignment,
                ind.speed_vector,
                return_details=True,
            )
            ind.completion_times = _to_completion_list(completion_times)

    return individuals


def _speed_level_cache(problem):
    cache = getattr(problem, "_speed_level_cache_sa", None)
    if cache is None:
        speed_levels = _problem_info(problem)["speed_levels"]
        ordered = sorted(speed_levels.keys(), key=lambda lv: speed_levels[lv])
        index_map = {lv: i for i, lv in enumerate(ordered)}
        cache = (ordered, index_map)
        problem._speed_level_cache_sa = cache
    return cache


def _min_speed_level(problem):
    ordered, _ = _speed_level_cache(problem)
    return ordered[0]


def _max_speed_level(problem):
    ordered, _ = _speed_level_cache(problem)
    return ordered[-1]


def _prev_speed_level(problem, level):
    ordered, index_map = _speed_level_cache(problem)
    idx = index_map.get(level)
    if idx is None or idx == 0:
        return None
    return ordered[idx - 1]


def _speed_up_one_level(problem, speed_vector, lap, job, stage):
    ordered, index_map = _speed_level_cache(problem)
    cur = speed_vector[lap][job][stage]
    idx = index_map.get(cur)
    if idx is None or idx >= len(ordered) - 1:
        return False
    speed_vector[lap][job][stage] = ordered[idx + 1]
    return True


def _speed_up_operations_no_decode(problem, individual, operations):
    if not operations:
        return None

    trial = deepcopy(individual)
    changed = False
    max_level = _max_speed_level(problem)

    for _, lap, job, stage in operations:
        current_level = _safe_speed_level(trial.speed_vector, lap, job, stage)
        if current_level is None or current_level >= max_level:
            continue
        if _speed_up_one_level(problem, trial.speed_vector, lap, job, stage):
            changed = True

    return trial if changed else None


def _speed_up_operations(problem, individual, operations):
    trial = _speed_up_operations_no_decode(problem, individual, operations)
    if trial is None:
        return None

    ms, twt, tec, completion_times = decode(
        problem,
        trial.job_sequence,
        trial.factory_assignment,
        trial.speed_vector,
        return_details=True,
    )
    trial.makespan = ms
    trial.TWT = twt
    trial.TEC = tec
    trial.completion_times = _to_completion_list(completion_times)
    return trial


def energy_save(problem, individual, eps=1e-9):
    if individual is None:
        return None

    min_level = _min_speed_level(problem)
    due_dates = problem.due_dates
    penalty_factors = problem.penalty_factors
    num_jobs = problem.num_jobs
    last_lap = problem.num_reentrances - 1
    last_stage = problem.num_stages - 1

    def pt(job, stage, lap, level):
        return problem.processing_times[job][stage][lap] / problem.speed_levels[level]

    def is_last_op(op_info):
        return op_info["lap"] == last_lap and op_info["stage"] == last_stage

    child = deepcopy(individual)

    ms, twt, tec, details = decode_with_critical_path(
        problem,
        child.job_sequence,
        child.factory_assignment,
        child.speed_vector,
        return_details=True,
    )

    op_info = deepcopy(details["operation_info"])
    completion = details["completion_times"][:]
    critical_ops = set(details["critical_operations"])

    child.makespan = ms
    child.TWT = twt
    child.TEC = tec
    child.completion_times = completion[:]

    candidates = []
    for op, op_meta in op_info.items():
        if op in critical_ops:
            continue

        lap = op_meta["lap"]
        job = op_meta["job"]
        stage = op_meta["stage"]
        speed_level = child.speed_vector[lap][job][stage]

        if speed_level <= min_level:
            continue

        if is_last_op(op_meta) and completion[job] > due_dates[job] + eps:
            continue

        candidates.append(op)

    random.shuffle(candidates)

    for op in candidates:
        op_meta = op_info[op]
        lap = op_meta["lap"]
        job = op_meta["job"]
        stage = op_meta["stage"]

        while True:
            old_level = child.speed_vector[lap][job][stage]
            if old_level <= min_level:
                break

            new_level = _prev_speed_level(problem, old_level)
            if new_level is None:
                break

            old_pt = pt(job, stage, lap, old_level)
            new_pt = pt(job, stage, lap, new_level)
            delta = new_pt - old_pt
            if delta <= eps:
                break

            machine_succ = op_meta.get("machine_successor")
            if machine_succ is not None:
                machine_gap = op_info[machine_succ]["start"] - op_meta["end"]
                if delta > machine_gap + eps:
                    break

            job_succ = op_meta.get("job_successor")
            if job_succ is not None:
                job_gap = op_info[job_succ]["start"] - op_meta["end"]
                if delta > job_gap + eps:
                    break

            if is_last_op(op_meta):
                if completion[job] > due_dates[job] + eps:
                    break
                if completion[job] + delta > due_dates[job] + eps:
                    break

            old_speed = problem.speed_levels[old_level]
            new_speed = problem.speed_levels[new_level]
            old_proc_energy = old_pt * 4.0 * (old_speed ** 2)
            new_proc_energy = new_pt * 4.0 * (new_speed ** 2)

            delta_idle = 0.0
            if machine_succ is not None:
                gap = op_info[machine_succ]["start"] - op_meta["end"]
                delta_idle = -min(delta, max(gap, 0.0)) * problem.unit_idle_power

            child.speed_vector[lap][job][stage] = new_level
            child.TEC += (new_proc_energy - old_proc_energy) + delta_idle

            op_meta["end"] += delta
            op_meta["proc_time"] += delta

            if is_last_op(op_meta):
                completion[job] += delta

    child.completion_times = completion
    child.makespan = max(completion) if completion else 0.0
    child.TWT = sum(
        max(completion[j] - due_dates[j], 0.0) * penalty_factors[j]
        for j in range(num_jobs)
    )
    return child


def makespan_reduce(problem, individual):
    if individual is None:
        return None

    _, _, _, details = decode_with_critical_path(
        problem,
        individual.job_sequence,
        individual.factory_assignment,
        individual.speed_vector,
        return_details=True,
    )
    return _speed_up_operations(problem, individual, details["critical_operations"])


def twt_reduce(problem, individual, eps=1e-9):
    if individual is None:
        return None

    _, _, _, details = decode_with_critical_path(
        problem,
        individual.job_sequence,
        individual.factory_assignment,
        individual.speed_vector,
        return_details=True,
    )

    info = _problem_info(problem)
    due_dates = info["due_dates"]
    completion_times = details["completion_times"]
    tardy_jobs = {
        j for j in range(info["num_jobs"])
        if completion_times[j] > due_dates[j] + eps
    }
    operations = [
        op for op, op_meta in details["operation_info"].items()
        if op_meta["job"] in tardy_jobs
    ]
    return _speed_up_operations(problem, individual, operations)


def knowledge_guided_speed_adjustment_operators(problem, population, eps=1e-9):
    offspring = []
    need_decode = []

    for parent in population:
        child_es = energy_save(problem, parent, eps=eps)
        if child_es is not None:
            offspring.append(child_es)

        _, _, _, details = decode_with_critical_path(
            problem,
            child_es.job_sequence,
            child_es.factory_assignment,
            child_es.speed_vector,
            return_details=True,
        )

        critical_operations = details["critical_operations"]
        completion_times = details["completion_times"]
        due_dates = problem.due_dates

        tardy_jobs = {
            j for j in range(problem.num_jobs)
            if completion_times[j] > due_dates[j] + eps
        }
        tardy_operations = [
            op for op, op_meta in details["operation_info"].items()
            if op_meta["job"] in tardy_jobs
        ]

        child_mr = _speed_up_operations_no_decode(problem, child_es, critical_operations)
        if child_mr is not None:
            offspring.append(child_mr)
            need_decode.append(child_mr)

        child_twt = _speed_up_operations_no_decode(problem, child_es, tardy_operations)
        if child_twt is not None:
            offspring.append(child_twt)
            need_decode.append(child_twt)

    _batch_decode_and_cache(problem, need_decode)
    return offspring