# problem.py

class Problem:
    def __init__(self,
                 num_speed_levels,
                 num_factorys,
                 num_jobs,
                 num_stages,
                 num_reentrances,
                 num_machines_per_stage,
                 processing_times,
                 due_dates,
                 priorities,
                 penalty_factors
                 ):
        self.num_speed_levels = num_speed_levels
        self.num_factorys = num_factorys
        self.num_jobs = num_jobs
        self.num_stages = num_stages
        self.num_reentrances = num_reentrances
        self.num_machines_per_stage = num_machines_per_stage
        self.processing_times = processing_times
        self.due_dates = due_dates
        self.unit_idle_power = 1.0

        self.speed_levels = {
            level: 1.0 + 0.5 * (level - 1)
            for level in range(1, num_speed_levels + 1)
        }

        self.priorities = priorities
        self.penalty_factors = penalty_factors

    @property
    def info(self):
        return (
            self.num_speed_levels,
            self.num_factorys,
            self.num_jobs,
            self.num_stages,
            self.num_reentrances,
            self.num_machines_per_stage,
            self.processing_times,
            self.due_dates,
            self.speed_levels,
            self.priorities,
            self.penalty_factors
        )