import numpy as np


def decode(problem, job_sequence, factory_assignment, speed_vector, return_details=False):
    """
    兼容完整序列和部分序列的 decode

    job_sequence:
        第一 lap 的工件顺序；可为部分序列
    factory_assignment:
        factory_assignment[job] = 工件所属工厂
    speed_vector:
        speed_vector[lap][job][stage] = 速度水平编号
    """
    (
        num_speed_levels,
        num_factories,
        num_jobs,
        num_stages,
        num_laps,
        num_machines_per_stage,
        processing_times,
        due_dates,
        speed_levels,
        priorities,
        penalty_factors
    ) = problem.info

    # 部分序列支持：只调度当前序列中的工件
    scheduled_jobs = list(job_sequence)
    if not scheduled_jobs:
        if return_details:
            return 0.0, 0.0, 0.0, {
                "completion_times": [0.0 for _ in range(num_jobs)],
                "scheduled_jobs": [],
            }
        return 0.0, 0.0, 0.0

    scheduled_job_set = set(scheduled_jobs)

    c_times = [
        [
            [[0.0 for _ in range(num_stages)] for _ in range(num_jobs)]
            for _ in range(num_laps)
        ]
        for _ in range(num_factories)
    ]

    machine_ready_times = [
        [[0.0 for _ in range(num_machines_per_stage[s])] for s in range(num_stages)]
        for _ in range(num_factories)
    ]

    machine_loads = [
        [[0.0 for _ in range(num_machines_per_stage[s])] for s in range(num_stages)]
        for _ in range(num_factories)
    ]

    machine_processing_energy = [
        [[0.0 for _ in range(num_machines_per_stage[s])] for s in range(num_stages)]
        for _ in range(num_factories)
    ]

    machine_idle_energy = [
        [[0.0 for _ in range(num_machines_per_stage[s])] for s in range(num_stages)]
        for _ in range(num_factories)
    ]

    first_lap_jobs_by_factory = [[] for _ in range(num_factories)]
    for job in scheduled_jobs:
        factory = factory_assignment[job]
        if not (0 <= factory < num_factories):
            raise ValueError(f"工件 {job} 的工厂编号非法: {factory}")
        first_lap_jobs_by_factory[factory].append(job)

    first_stage_sequences = [[[] for _ in range(num_laps)] for _ in range(num_factories)]

    unit_idle_power = problem.unit_idle_power

    def get_actual_speed(lap, job, stage):
        speed_level = speed_vector[lap][job][stage]
        return speed_levels[speed_level]

    def get_processing_time(lap, job, stage):
        base_time = processing_times[job][stage][lap]
        speed = get_actual_speed(lap, job, stage)
        return base_time / speed

    def get_unit_processing_power(lap, job, stage):
        speed = get_actual_speed(lap, job, stage)
        return 4 * (speed ** 2)

    for factory in range(num_factories):
        lap_sequence = first_lap_jobs_by_factory[factory][:]

        for lap in range(num_laps):
            if lap > 0:
                lap_sequence = sorted(
                    lap_sequence,
                    key=lambda job: c_times[factory][lap - 1][job][num_stages - 1]
                )

            first_stage_sequences[factory][lap] = lap_sequence[:]

            for stage in range(num_stages):
                if stage == 0:
                    stage_sequence = lap_sequence
                else:
                    stage_sequence = sorted(
                        lap_sequence,
                        key=lambda job: c_times[factory][lap][job][stage - 1]
                    )

                for job in stage_sequence:
                    if lap == 0 and stage == 0:
                        job_ready_time = 0.0
                    elif stage == 0:
                        job_ready_time = c_times[factory][lap - 1][job][num_stages - 1]
                    else:
                        job_ready_time = c_times[factory][lap][job][stage - 1]

                    p_time = get_processing_time(lap, job, stage)

                    best_machine = min(
                        range(num_machines_per_stage[stage]),
                        key=lambda m: (
                            max(machine_ready_times[factory][stage][m], job_ready_time) + p_time,
                            machine_ready_times[factory][stage][m],
                            machine_loads[factory][stage][m],
                        )
                    )

                    machine_ready = machine_ready_times[factory][stage][best_machine]
                    start_time = max(machine_ready, job_ready_time)
                    end_time = start_time + p_time

                    idle_time = start_time - machine_ready
                    unit_processing_power = get_unit_processing_power(lap, job, stage)

                    machine_processing_energy[factory][stage][best_machine] += p_time * unit_processing_power
                    machine_idle_energy[factory][stage][best_machine] += idle_time * unit_idle_power

                    c_times[factory][lap][job][stage] = end_time
                    machine_ready_times[factory][stage][best_machine] = end_time
                    machine_loads[factory][stage][best_machine] += p_time

    last_lap = num_laps - 1
    last_stage = num_stages - 1

    makespan = 0.0
    twt = 0.0
    completion_times = [0.0 for _ in range(num_jobs)]

    # 只对部分序列中的工件统计目标值
    for job in scheduled_jobs:
        factory = factory_assignment[job]
        completion = c_times[factory][last_lap][job][last_stage]
        completion_times[job] = completion
        makespan = max(makespan, completion)
        twt += max(completion - due_dates[job], 0.0) * penalty_factors[job]

    tec = 0.0
    for factory in range(num_factories):
        for stage in range(num_stages):
            tec += sum(machine_processing_energy[factory][stage])
            tec += sum(machine_idle_energy[factory][stage])

    if return_details:
        return makespan, twt, tec,  completion_times

    return makespan, twt, tec


def decode_batch(problem, job_sequences, seq_lengths, factory_assignments, speed_vectors):
    """
    Pure-Python batch decoder with the same interface as the numba version.

    Parameters follow Algorithm.Numba.RLEMTO.decode.decode_batch:
        job_sequences[i]: job sequence of individual i, padded or unpadded
        seq_lengths[i]: valid sequence length of individual i
        factory_assignments[i]: factory assignment of individual i
        speed_vectors[i]: speed vector of individual i

    Returns:
        makespans, twts, tecs, completion_times_batch
    """
    (
        _num_speed_levels,
        _num_factories,
        num_jobs,
        _num_stages,
        _num_laps,
        _num_machines_per_stage,
        _processing_times,
        _due_dates,
        _speed_levels,
        _priorities,
        _penalty_factors,
    ) = problem.info

    popsize = len(seq_lengths)
    makespans = np.zeros(popsize, dtype=np.float64)
    twts = np.zeros(popsize, dtype=np.float64)
    tecs = np.zeros(popsize, dtype=np.float64)
    completion_times_batch = np.zeros((popsize, num_jobs), dtype=np.float64)

    for i in range(popsize):
        seq_length = int(seq_lengths[i])
        job_sequence = list(job_sequences[i])[:seq_length]
        factory_assignment = factory_assignments[i]
        speed_vector = speed_vectors[i]

        makespan, twt, tec, completion_times = decode(
            problem,
            job_sequence,
            factory_assignment,
            speed_vector,
            return_details=True,
        )

        if isinstance(completion_times, dict):
            completion_times = completion_times["completion_times"]

        makespans[i] = makespan
        twts[i] = twt
        tecs[i] = tec
        completion_times_batch[i, :] = np.asarray(completion_times, dtype=np.float64)

    return makespans, twts, tecs, completion_times_batch

