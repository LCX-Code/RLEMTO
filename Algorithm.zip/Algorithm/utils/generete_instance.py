import os
import random
from dataclasses import dataclass

from Algorithm.utils.decode import decode


@dataclass
class TempProblem:
    num_factorys: int
    num_jobs: int
    num_stages: int
    num_reentrances: int
    num_machines_per_stage: list
    processing_times: list
    due_dates: list
    speed_levels: dict
    priorities: list
    penalty_factors: list
    unit_idle_power: float = 1.0

    @property
    def info(self):
        return (
            self.num_factorys,
            self.num_jobs,
            self.num_stages,
            self.num_reentrances,
            self.num_machines_per_stage,
            self.processing_times,
            self.due_dates,
            self.speed_levels,
            self.priorities,
            self.penalty_factors,
        )


def build_speed_levels(num_speed_levels):
    return {
        level: 1.0 + 0.5 * (level - 1)
        for level in range(1, num_speed_levels + 1)
    }


def calculate_job_workload(problem):
    return [
        sum(
            problem.processing_times[j][s][l]
            for l in range(problem.num_reentrances)
            for s in range(problem.num_stages)
        )
        for j in range(problem.num_jobs)
    ]


def neh_initial_sequence(problem):
    workloads = calculate_job_workload(problem)
    ordered_jobs = sorted(range(problem.num_jobs), key=lambda j: workloads[j], reverse=True)

    num_jobs = problem.num_jobs
    num_stages = problem.num_stages
    num_laps = problem.num_reentrances
    speed_codes = list(problem.speed_levels.keys())

    speed_vector = [
        [
            [random.choice(speed_codes) for _ in range(num_stages)]
            for _ in range(num_jobs)
        ]
        for _ in range(num_laps)
    ]

    factory_sequences = [[] for _ in range(problem.num_factorys)]

    for job in ordered_jobs:
        best_factory = None
        best_pos = None
        best_cmax = float("inf")

        for f in range(problem.num_factorys):
            current_seq = factory_sequences[f]
            for pos in range(len(current_seq) + 1):
                trial_factory_sequences = [seq[:] for seq in factory_sequences]
                trial_factory_sequences[f].insert(pos, job)

                trial_job_sequence = []
                trial_factory_assignment = [0] * num_jobs

                for factory_id, seq in enumerate(trial_factory_sequences):
                    for j in seq:
                        trial_job_sequence.append(j)
                        trial_factory_assignment[j] = factory_id

                cmax, _, _ = decode(
                    problem=problem,
                    job_sequence=trial_job_sequence,
                    factory_assignment=trial_factory_assignment,
                    speed_vector=speed_vector,
                    return_details=False,
                )

                if cmax < best_cmax:
                    best_cmax = cmax
                    best_factory = f
                    best_pos = pos

        factory_sequences[best_factory].insert(best_pos, job)

    final_job_sequence = []
    final_factory_assignment = [0] * num_jobs

    for factory_id, seq in enumerate(factory_sequences):
        for j in seq:
            final_job_sequence.append(j)
            final_factory_assignment[j] = factory_id

    return final_job_sequence, final_factory_assignment


def build_due_dates1(num_jobs, processing_times):
    return [
        int(sum(sum(stage_times) for stage_times in processing_times[i]) * (1 + random.random() * 3))
        for i in range(num_jobs)
    ]


def build_due_dates2(problem):
    seq, factory_assignment = neh_initial_sequence(problem)
    num_jobs = problem.num_jobs
    num_stages = problem.num_stages
    num_laps = problem.num_reentrances
    speed_codes = list(problem.speed_levels.keys())

    speed_vector = [
        [
            [random.choice(speed_codes) for _ in range(num_stages)]
            for _ in range(num_jobs)
        ]
        for _ in range(num_laps)
    ]

    cmax, _, _ = decode(
        problem=problem,
        job_sequence=seq,
        factory_assignment=factory_assignment,
        speed_vector=speed_vector,
        return_details=False,
    )

    low, high = 0.1 * cmax, 0.5 * cmax
    return [int(random.uniform(low, high)) for _ in range(num_jobs)]


def build_priorities_and_penalties(num_jobs):
    priorities = [random.choice([1, 2, 3]) for _ in range(num_jobs)]
    penalty_map = {1: 2.0, 2: 1.0, 3: 0.5}
    penalty_factors = [penalty_map[p] for p in priorities]
    return priorities, penalty_factors


def generate_instance(size="large", due_date_mode=2, num_speed_levels=None):
    if size == "large":
        num_factorys = random.choice([2, 3, 4, 5])
        num_jobs = random.choice([25, 30, 35, 40])
        num_stages = random.choice([3, 5, 8, 10])
        num_reentrances = random.randint(1, 4)
        num_machines_per_stage = [random.randint(2, 4) for _ in range(num_stages)]
        processing_times = [
            [[random.randint(1, 20) for _ in range(num_reentrances)] for _ in range(num_stages)]
            for _ in range(num_jobs)
        ]
    else:
        num_factorys = random.choice([2, 3])
        num_jobs = random.choice([5, 10, 15, 20])
        num_stages = random.choice([2, 3, 4, 5])
        num_reentrances = random.randint(1, 2)
        num_machines_per_stage = [random.randint(1, 2) for _ in range(num_stages)]
        processing_times = [
            [[random.randint(1, 10) for _ in range(num_reentrances)] for _ in range(num_stages)]
            for _ in range(num_jobs)
        ]

    if num_speed_levels is None:
        num_speed_levels = random.choice([6, 7, 8])
    speed_levels = build_speed_levels(num_speed_levels)

    dummy_due_dates = [0] * num_jobs
    dummy_priorities = [1] * num_jobs
    dummy_penalty_factors = [1.0] * num_jobs

    problem = TempProblem(
        num_factorys=num_factorys,
        num_jobs=num_jobs,
        num_stages=num_stages,
        num_reentrances=num_reentrances,
        num_machines_per_stage=num_machines_per_stage,
        processing_times=processing_times,
        due_dates=dummy_due_dates,
        speed_levels=speed_levels,
        priorities=dummy_priorities,
        penalty_factors=dummy_penalty_factors,
    )

    due_dates = build_due_dates1(num_jobs, processing_times) if due_date_mode == 1 else build_due_dates2(problem)
    priorities, penalty_factors = build_priorities_and_penalties(num_jobs)

    return {
        "speed_level_count": num_speed_levels,
        "speed_levels": speed_levels,
        "factories": num_factorys,
        "jobs": num_jobs,
        "stages": num_stages,
        "reentrances": num_reentrances,
        "machines": num_machines_per_stage,
        "times": processing_times,
        "due_dates": due_dates,
        "priorities": priorities,
        "penalty_factors": penalty_factors,
    }


def save_instance(data, filename):
    with open(filename, "w", encoding="utf-8") as f:
        # The first line indicates the number of speed levels: 6, 7, or 8.
        f.write(f"{data['speed_level_count']}\n")
        f.write(f"{data['factories']}\n")
        f.write(f"{data['jobs']}\n")
        f.write(f"{data['stages']}\n")
        f.write(f"{data['reentrances']}\n")
        f.write(" ".join(map(str, data["machines"])) + "\n")

        for job in data["times"]:
            flat = []
            for stage in job:
                flat.extend(stage)
            f.write(" ".join(map(str, flat)) + "\n")

        f.write(" ".join(map(str, data["due_dates"])) + "\n")
        f.write(" ".join(map(str, data["priorities"])) + "\n")
        f.write(" ".join(map(str, data["penalty_factors"])) + "\n")


if __name__ == "__main__":
    save_dir = "../../Experiment/instance/large/"
    os.makedirs(save_dir, exist_ok=True)

    for speed_level_count in [ 7]:
        for idx in range(1):
            data = generate_instance(
                size="large",
                due_date_mode=2,
                num_speed_levels=speed_level_count
            )
            fname = (
                f"{save_dir}V{data['speed_level_count']}"
                f"_F{data['factories']}_L{data['reentrances']}"
                f"_J{data['jobs']}_S{data['stages']}.txt"
            )
            save_instance(data, fname)
            print(fname)
