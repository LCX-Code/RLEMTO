from Algorithm.utils.problem import Problem
import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


def read_instances(file_path):
    with open(file_path, "r", encoding="utf-8") as f:
        lines = [line.strip() for line in f if line.strip()]

    num_speed_levels = int(lines[0])
    num_factorys = int(lines[1])
    num_jobs = int(lines[2])
    num_stages = int(lines[3])
    num_laps = int(lines[4])
    num_machines_per_stage = list(map(int, lines[5].split()))

    raw_times = [
        list(map(int, lines[6 + i].split()))
        for i in range(num_jobs)
    ]

    processing_times = []
    for row in raw_times:
        job_data = []
        idx = 0
        for s in range(num_stages):
            job_data.append(row[idx:idx + num_laps])
            idx += num_laps
        processing_times.append(job_data)

    due_dates = list(map(float, lines[6 + num_jobs].split()))
    priorities = list(map(int, lines[7 + num_jobs].split()))
    penalty_factors = list(map(float, lines[8 + num_jobs].split()))

    problem = Problem(
        num_speed_levels,
        num_factorys,
        num_jobs,
        num_stages,
        num_laps,
        num_machines_per_stage,
        processing_times,
        due_dates,
        priorities,
        penalty_factors
    )

    return problem

