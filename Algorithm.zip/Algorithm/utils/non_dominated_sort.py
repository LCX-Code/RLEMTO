def objective_vector(individual):
    return [individual.makespan, individual.TWT, individual.TEC]

def dominates(a, b):
    a_obj = objective_vector(a)
    b_obj = objective_vector(b)
    no_worse = True
    strictly_better = False
    for x, y in zip(a_obj, b_obj):
        if x > y:
            no_worse = False
            break
        if x < y:
            strictly_better = True
    return no_worse and strictly_better

def non_dominated_sort(population):
    domination_sets = [set() for _ in population]
    dominated_count = [0 for _ in population]
    fronts = [[]]

    for i, p in enumerate(population):
        for j, q in enumerate(population):
            if i == j:
                continue
            if dominates(p, q):
                domination_sets[i].add(j)
            elif dominates(q, p):
                dominated_count[i] += 1
        if dominated_count[i] == 0:
            p.rank = 0
            fronts[0].append(i)

    front_index = 0
    while front_index < len(fronts) and fronts[front_index]:
        next_front = []
        for i in fronts[front_index]:
            for j in domination_sets[i]:
                dominated_count[j] -= 1
                if dominated_count[j] == 0:
                    population[j].rank = front_index + 1
                    next_front.append(j)
        if next_front:
            fronts.append(next_front)
        front_index += 1

    return [[population[i] for i in front] for front in fronts if front]